import sys

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
from datetime import datetime

from Usuarios.Administrador import Administrador
from Usuarios.Alumno import Alumno
from Usuarios.Profesor import Profesor
from Usuarios.UMaestro import Maestro
from Usuarios.Materia import Materia
from Usuarios.Reporte import Reporte
from Usuarios.GrupoAlumno import GrupoAlumno
from Conexion import *

class AnuncioAgregar(QWidget):
    subirSignal = Signal()
    cancelarSignal = Signal()
    
    def __init__(self):
        super().__init__()
        
        # Widgets
        self.__titulo = QLabel('Título:')
        self.__descripcion = QLabel('Descripción:')
        self.__lineTitulo = QLineEdit()
        self.__textDescripcion = QTextEdit()
        self.__bSubir = QPushButton('Anunciar')
        self.__bCancelar = QPushButton('Cancelar')

        # Layout formulario
        layoutForm = QFormLayout()
        layoutForm.addRow(self.__titulo, self.__lineTitulo)
        layoutForm.addRow(self.__descripcion)
        layoutForm.addRow(self.__textDescripcion)

        # Layout botones
        layoutQH = QHBoxLayout()
        layoutQH.addWidget(self.__bSubir)
        layoutQH.addWidget(self.__bCancelar)

        # Layout principal
        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH)
        self.setLayout(layoutQV)

        # Conexiones
        self.__bSubir.clicked.connect(self.subir)
        self.__bCancelar.clicked.connect(self.cancelar)

    @Slot()
    def subir(self):
        titulo = self.__lineTitulo.text().strip()
        descripcion = self.__textDescripcion.toPlainText().strip()

        if not titulo or not descripcion:
            QMessageBox.warning(self, 'Campos Vacíos', 'Debes llenar todos los campos.')
            return

        confirmar = QMessageBox.question(
            self,
            'Confirmar publicación',
            '¿Estás seguro de que deseas publicar este anuncio?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )

        if confirmar == QMessageBox.Yes:
            exito = insertar_anuncio(titulo, descripcion)
            if exito:
                QMessageBox.information(self, 'Éxito', 'Anuncio publicado correctamente.')
                self.subirSignal.emit()
            else:
                QMessageBox.critical(self, 'Error', 'No se pudo publicar el anuncio.')

    @Slot()
    def cancelar(self):
        if QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Cancel
        ) == QMessageBox.Ok:
            self.cancelarSignal.emit()
          
class AnuncioEditar(QWidget):
    editarSignal = Signal()
    cancelarSignal = Signal()

    def __init__(self):
        super().__init__()

        self.__clave = QLabel('ID del anuncio:')
        self.__lineClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar')
        self.__bCancelarBusqueda = QPushButton('Cancelar')

        self.__titulo = QLabel('Título:')
        self.__lineTitulo = QLineEdit()
        self.__descripcion = QLabel('Descripción:')
        self.__textDescripcion = QTextEdit()
        self.__bGuardar = QPushButton('Guardar Cambios')
        self.__bCancelarEdicion = QPushButton('Cancelar')

        self.__titulo.hide()
        self.__lineTitulo.hide()
        self.__descripcion.hide()
        self.__textDescripcion.hide()
        self.__bGuardar.hide()
        self.__bCancelarEdicion.hide()

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave, self.__lineClave)

        layoutBotonesBusqueda = QHBoxLayout()
        layoutBotonesBusqueda.addWidget(self.__bBuscar)
        layoutBotonesBusqueda.addWidget(self.__bCancelarBusqueda)

        layoutFormEdicion = QFormLayout()
        layoutFormEdicion.addRow(self.__titulo, self.__lineTitulo)
        layoutFormEdicion.addRow(self.__descripcion, self.__textDescripcion)

        layoutBotonesEdicion = QHBoxLayout()
        layoutBotonesEdicion.addWidget(self.__bGuardar)
        layoutBotonesEdicion.addWidget(self.__bCancelarEdicion)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutBotonesBusqueda)
        layoutQV.addLayout(layoutFormEdicion)
        layoutQV.addLayout(layoutBotonesEdicion)
        self.setLayout(layoutQV)

        self.__bBuscar.clicked.connect(self.buscar)
        self.__bGuardar.clicked.connect(self.guardar)
        self.__bCancelarBusqueda.clicked.connect(self.cancelar)
        self.__bCancelarEdicion.clicked.connect(self.cancelar)

    @Slot()
    def buscar(self):
        from Conexion import buscar_anuncio  # Evitar ciclo de importación
        id_texto = self.__lineClave.text().strip()

        if not id_texto.isdigit():
            QMessageBox.warning(self, "Error", "El ID debe ser numérico.")
            return

        anuncio = buscar_anuncio(int(id_texto))
        if not anuncio:
            QMessageBox.information(self, "No encontrado", "No se encontró un anuncio con esa ID.")
            return

        self.__lineTitulo.setText(anuncio["titulo"])
        self.__textDescripcion.setText(anuncio["descripcion"])
        self.__id_actual = anuncio["id"]

        self.__titulo.show()
        self.__lineTitulo.show()
        self.__descripcion.show()
        self.__textDescripcion.show()
        self.__bGuardar.show()
        self.__bCancelarEdicion.show()

        self.__clave.hide()
        self.__lineClave.hide()
        self.__bBuscar.hide()
        self.__bCancelarBusqueda.hide()

    @Slot()
    def guardar(self):
        from Conexion import actualizar_anuncio
        nuevo_titulo = self.__lineTitulo.text().strip()
        nueva_desc = self.__textDescripcion.toPlainText().strip()

        if not nuevo_titulo or not nueva_desc:
            QMessageBox.warning(self, "Error", "Ningún campo puede estar vacío.")
            return

        confirmar = QMessageBox.question(
            self,
            'Confirmar edición',
            '¿Deseas guardar los cambios?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )

        if confirmar == QMessageBox.Yes:
            exito = actualizar_anuncio(self.__id_actual, nuevo_titulo, nueva_desc)
            if exito:
                QMessageBox.information(self, "Éxito", "Anuncio actualizado correctamente.")
                self.editarSignal.emit()
            else:
                QMessageBox.critical(self, "Error", "No se pudo actualizar el anuncio.")

    @Slot()
    def cancelar(self):
        respuesta = QMessageBox.question(
            self,
            'Cancelar',
            '¿Deseas cancelar esta operación?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if respuesta == QMessageBox.Yes:
            self.cancelarSignal.emit()
  
class AnuncioBorrar(QWidget):
    borrarSignal = Signal()
    cancelarSignal = Signal()

    def __init__(self):
        super().__init__()

        from Conexion import buscar_anuncio  # Asegúrate de evitar ciclos de importación
        self.buscar_anuncio = buscar_anuncio

        # Widgets
        self.__clave = QLabel('Inserte la clave del anuncio:')
        self.__lClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar anuncio')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bCancelar2 = QPushButton('Cancelar')
        self.__bBorrar = QPushButton('Eliminar')
        self.__infoAnuncio = QLabel('Anuncio')

        self.__infoAnuncio.hide()
        self.__bBorrar.hide()
        self.__bCancelar2.hide()

        # Layout formulario
        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave, self.__lClave)

        # Layout botones iniciales
        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        # Layout botones de confirmación
        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bBorrar)
        layoutQH2.addWidget(self.__bCancelar2)

        # Layout principal
        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addWidget(self.__infoAnuncio)
        layoutQV.addLayout(layoutQH2)
        self.setLayout(layoutQV)

        # Conexiones
        self.__bBuscar.clicked.connect(self.mostrar_info)
        self.__bBorrar.clicked.connect(self.borrar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bCancelar2.clicked.connect(self.cancelar)

    @Slot()
    def mostrar_info(self):
        from Conexion import buscar_anuncio
        id_texto = self.__lClave.text().strip()
        if not id_texto.isdigit():
            QMessageBox.warning(self, "Error", "La clave debe ser un número.")
            return

        anuncio = buscar_anuncio(int(id_texto))
        if not anuncio:
            QMessageBox.warning(self, "No encontrado", "No se encontró ningún anuncio con esa clave.")
            return

        self.__infoAnuncio.setText(
            f"ID: {anuncio['id']}\nTítulo: {anuncio['titulo']}\nDescripción:\n{anuncio['descripcion']}"
        )
        self.__infoAnuncio.show()
        self.__bBorrar.show()
        self.__bCancelar2.show()
        self.__bBuscar.hide()
        self.__bCancelar1.hide()

    @Slot()
    def borrar(self):
        from Conexion import eliminar_anuncio
        clave = self.__lClave.text().strip()
        if not clave.isdigit():
            QMessageBox.warning(self, "Error", "Clave inválida.")
            return

        confirmacion = QMessageBox.question(
            self,
            'Eliminar anuncio',
            '¿Seguro que deseas borrar este anuncio?\nNo se podrá recuperar.',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if confirmacion == QMessageBox.Yes:
            exito = eliminar_anuncio(int(clave))
            if exito:
                QMessageBox.information(self, "Éxito", "Anuncio eliminado correctamente.")
                self.borrarSignal.emit()
            else:
                QMessageBox.critical(self, "Error", "No se pudo eliminar el anuncio.")

    @Slot()
    def cancelar(self):
        respuesta = QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán.',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if respuesta == QMessageBox.Yes:
            self.cancelarSignal.emit()
  
class UsuarioAgregar(QWidget):
    agregarSignal = Signal()
    cancelarSignal = Signal()
    
    def __init__(self):
        super().__init__()
        
        # Widgets
        self.__agregarU = QLabel('AGREGAR USUARIO')
        self.__agregarU.setAlignment(Qt.AlignCenter)
        self.__nombre = QLabel('Nombre:')
        self.__apellidoP = QLabel('Apellido Paterno:')
        self.__apellidoM = QLabel('Apellido Materno:')
        self.__edad = QLabel('Edad:')
        self.__curp = QLabel('CURP:')
        self.__correo = QLabel('Correo:')
        self.__rango = QLabel('Rango:')

        self.__nombreEdit = QLineEdit()
        self.__apellidoPEdit = QLineEdit()
        self.__apellidoMEdit = QLineEdit()
        self.__curpEdit = QLineEdit()
        self.__correoEdit = QLineEdit()
        self.__spin = QSpinBox()
        self.__spin.setValue(18)
        self.__spin.setRange(0, 100)

        self.__maestro = QRadioButton('Maestro')
        self.__administrador = QRadioButton('Administrador')
        self.__profesor = QRadioButton('Profesor')
        self.__alumno = QRadioButton('Alumno')

        self.__bAgregar = QPushButton('Agregar')
        self.__bCancelar = QPushButton('Cancelar')

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__agregarU)
        layoutForm.addRow(self.__nombre,self.__nombreEdit)
        layoutForm.addRow(self.__apellidoP,self.__apellidoPEdit)
        layoutForm.addRow(self.__apellidoM,self.__apellidoMEdit)
        layoutForm.addRow(self.__edad,self.__spin)
        layoutForm.addRow(self.__curp,self.__curpEdit)
        layoutForm.addRow(self.__correo,self.__correoEdit)

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__maestro)
        layoutQH1.addWidget(self.__administrador)
        layoutQH1.addWidget(self.__profesor)
        layoutQH1.addWidget(self.__alumno)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bAgregar)
        layoutQH2.addWidget(self.__bCancelar)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addWidget(self.__rango)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addLayout(layoutQH2)
        self.setLayout(layoutQV)

        self.__bAgregar.clicked.connect(self.agregar)
        self.__bCancelar.clicked.connect(self.cancelar)
    
    @Slot()
    def agregar(self):
        resp = QMessageBox.information(
            self, '', 'Verifique que los datos sean correctos',
            QMessageBox.Ok | QMessageBox.Cancel, QMessageBox.Ok
        )
        if resp != QMessageBox.Ok:
            return

        nombre = self.__nombreEdit.text()
        apellidoP = self.__apellidoPEdit.text()
        apellidoM = self.__apellidoMEdit.text()
        edad = self.__spin.value()
        curp = self.__curpEdit.text()
        correo = self.__correoEdit.text()

        if self.__maestro.isChecked():
            usuario = Maestro(nombre, apellidoP, apellidoM, edad, curp, correo)
        elif self.__administrador.isChecked():
            usuario = Administrador(nombre, apellidoP, apellidoM, edad, curp, correo)
        elif self.__profesor.isChecked():
            usuario = Profesor(nombre, apellidoP, apellidoM, edad, curp, correo)
        elif self.__alumno.isChecked():
            usuario = Alumno(nombre, apellidoP, apellidoM, edad, curp, correo)
        else:
            QMessageBox.warning(self, 'Error', 'Selecciona un rol válido.')
            return

        exito = insertar_usuario(
            usuario.clave, usuario.nombre, usuario.apellidoP,
            usuario.apellidoM, usuario.edad, usuario.curp,
            usuario.correo, usuario.contrasena, usuario.obtenerRol()
        )

        if exito:
            QMessageBox.information(self, 'Éxito', 'Usuario registrado correctamente.')
            self.agregarSignal.emit()
        else:
            QMessageBox.critical(self, 'Error', 'No se pudo registrar el usuario.')

    @Slot()
    def cancelar(self):
        resp = QMessageBox.information(self,'','¿Seguro que quieres cancelar?\nLos cambios no se guardarán',QMessageBox.Ok|QMessageBox.Cancel,QMessageBox.Cancel)
        if resp == QMessageBox.Ok:
            self.cancelarSignal.emit()

class UsuarioBuscar(QWidget):
    cancelarSignal = Signal()
    salirSignal = Signal()
    
    def __init__(self):
        super().__init__()
        self.__clave = QLabel('Inserte la clave del usuario:')
        self.__lClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar usuario')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bSalir = QPushButton('Salir')
        self.__infoUsuario = QLabel('Usuario')
        self.__infoUsuario.hide()
        self.__bSalir.hide()
     
        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lClave)

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bSalir)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addWidget(self.__infoUsuario)
        layoutQV.addLayout(layoutQH2)
        self.setLayout(layoutQV)
        
        self.__bBuscar.clicked.connect(self.buscar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bSalir.clicked.connect(self.salir)
    
    @Slot()
    def buscar(self):
        clave = self.__lClave.text().strip()
        if not clave:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar una clave.")
            return

        usuario = buscar_usuario(clave)
        if usuario:
            texto = f"""
    <b>Clave:</b> {usuario['clave']}<br>
    <b>Nombre:</b> {usuario['nombre']} {usuario['apellidoP']} {usuario['apellidoM']}<br>
    <b>Edad:</b> {usuario['edad']}<br>
    <b>CURP:</b> {usuario['curp']}<br>
    <b>Correo:</b> {usuario['correo']}<br>
    <b>Rol:</b> {usuario['rol']}
    """
            self.__infoUsuario.setText(texto)
            self.__infoUsuario.setTextFormat(Qt.RichText)
        else:
            self.__infoUsuario.setText("<b>Usuario no encontrado.</b>")

        self.__clave.hide()
        self.__lClave.hide()
        self.__bBuscar.hide()
        self.__bCancelar1.hide()
        self.__infoUsuario.show()
        self.__bSalir.show()
        
    @Slot()
    def cancelar(self):
        if QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        ) == QMessageBox.Yes:
            self.cancelarSignal.emit()
        
    @Slot()
    def salir(self):
        self.salirSignal.emit()
        
class UsuarioEditar(QWidget):
    editarSignal = Signal()
    cancelarSignal = Signal()
    
    def __init__(self):
        super().__init__()
        self.__editar = QLabel('EDITAR')
        self.__editar.setAlignment(Qt.AlignCenter)
        self.__clave = QLabel('Clave:')
        self.__lClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar')
        self.__bCancelar1 = QPushButton('Cancelar1')
        self.__bCancelar2 = QPushButton('Cancelar2')

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__editar)
        layoutForm.addRow(self.__clave,self.__lClave)
        
        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        self.__nombre = QLabel('Nombre:')
        self.__nombre.hide()
        self.__apellidoP = QLabel('Apellido Paterno:')
        self.__apellidoP.hide()
        self.__apellidoM = QLabel('Apellido Materno:')
        self.__apellidoM.hide()
        self.__edad = QLabel('Edad:')
        self.__edad.hide()
        self.__spin = QSpinBox()
        self.__spin.hide()
        self.__spin.setValue(18)
        self.__spin.setRange(0,100)
        self.__curp = QLabel('CURP:')
        self.__curp.hide()
        self.__correo = QLabel('Correo:')
        self.__correo.hide()
        self.__rango = QLabel('Rango:')
        self.__rango.hide()
        self.__bCancelar2.hide()

        self.__maestro = QRadioButton('Maestro')
        self.__maestro.hide()
        self.__administrador = QRadioButton('Administrador')
        self.__administrador.hide()
        self.__profesor = QRadioButton('Profesor')
        self.__profesor.hide()
        self.__alumno = QRadioButton('Alumno')
        self.__alumno.hide()

        self.__bEditar = QPushButton('Editar')
        self.__bEditar.hide()

        self.__lNombre = QLineEdit()
        self.__lApellidoP = QLineEdit()
        self.__lApellidoM = QLineEdit()
        self.__lCurp = QLineEdit()
        self.__lCorreo = QLineEdit()

        self.__lNombre.hide()
        self.__lApellidoP.hide()
        self.__lApellidoM.hide()
        self.__lCurp.hide()
        self.__lCorreo.hide()


        layoutForm1 = QFormLayout()
        layoutForm1.addRow(self.__nombre,self.__lNombre)
        layoutForm1.addRow(self.__apellidoP,self.__lApellidoP)
        layoutForm1.addRow(self.__apellidoM,self.__lApellidoM)
        layoutForm1.addRow(self.__edad,self.__spin)
        layoutForm1.addRow(self.__curp,self.__lCurp)
        layoutForm1.addRow(self.__correo,self.__lCorreo)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__maestro)
        layoutQH2.addWidget(self.__administrador)
        layoutQH2.addWidget(self.__profesor)
        layoutQH2.addWidget(self.__alumno)

        layoutQH3 = QHBoxLayout()
        layoutQH3.addWidget(self.__bEditar)
        layoutQH3.addWidget(self.__bCancelar2)

        self.__bBuscar.clicked.connect(self.buscar)
        self.__bEditar.clicked.connect(self.editar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bCancelar2.clicked.connect(self.cancelar)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addLayout(layoutForm1)
        layoutQV.addWidget(self.__rango)
        layoutQV.addLayout(layoutQH2)
        layoutQV.addLayout(layoutQH3)
        self.setLayout(layoutQV)
    
    @Slot()
    def buscar(self):
        clave = self.__lClave.text().strip()
        if not clave:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar una clave.")
            return

        usuario = buscar_usuario(clave)
        if not usuario:
            QMessageBox.warning(self, "No encontrado", "No se encontró el usuario.")
            return

        self.__claveUsuario = clave

        self.__lNombre.setText(usuario["nombre"])
        self.__lApellidoP.setText(usuario["apellidoP"])
        self.__lApellidoM.setText(usuario["apellidoM"])
        self.__spin.setValue(usuario["edad"])
        self.__lCurp.setText(usuario["curp"])
        self.__lCorreo.setText(usuario["correo"])

        rol = usuario["rol"]
        if rol == "Maestro":
          self.__maestro.setChecked(True)
        elif rol == "Administrador":
            self.__administrador.setChecked(True)
        elif rol == "Profesor":
            self.__profesor.setChecked(True)
        elif rol == "Alumno":
            self.__alumno.setChecked(True)

        self.__clave.hide()
        self.__lClave.hide()
        self.__bBuscar.hide()
        self.__bCancelar1.hide()

        self.__nombre.show()
        self.__apellidoP.show()
        self.__apellidoM.show()
        self.__edad.show()
        self.__spin.show()
        self.__curp.show()
        self.__correo.show()
        self.__rango.show()

        self.__lNombre.show()
        self.__lApellidoP.show()
        self.__lApellidoM.show()
        self.__lCurp.show()
        self.__lCorreo.show()

        self.__maestro.show()
        self.__administrador.show()
        self.__profesor.show()
        self.__alumno.show()

        self.__bEditar.show()
        self.__bCancelar2.show()

    @Slot()
    def editar(self):
        resp = QMessageBox.question(
            self, '', '¿Seguro que desea editar la información?',
            QMessageBox.Ok | QMessageBox.Cancel, QMessageBox.Ok
        )
        if resp != QMessageBox.Ok:
            return

        nombre = self.__lNombre.text()
        apellidoP = self.__lApellidoP.text()
        apellidoM = self.__lApellidoM.text()
        edad = self.__spin.value()
        curp = self.__lCurp.text()
        correo = self.__lCorreo.text()

        if self.__maestro.isChecked():
            rol = "Maestro"
        elif self.__administrador.isChecked():
            rol = "Administrador"
        elif self.__profesor.isChecked():
            rol = "Profesor"
        elif self.__alumno.isChecked():
            rol = "Alumno"
        else:
            QMessageBox.warning(self, "Error", "Selecciona un rol válido.")
            return

        exito = actualizar_usuario(self.__claveUsuario, nombre, apellidoP, apellidoM, edad, curp, correo, rol)

        if exito:
            QMessageBox.information(self, "Éxito", "Usuario actualizado correctamente.")
            self.editarSignal.emit()
        else:
            QMessageBox.critical(self, "Error", "No se pudo actualizar el usuario.")
    
    @Slot()
    def cancelar(self):
        resp = QMessageBox.information(self,'','¿Seguro que quieres cancelar?\nLos cambios no se guardarán',QMessageBox.Ok|QMessageBox.Cancel,QMessageBox.Cancel)
        if resp == QMessageBox.Ok:
            self.cancelarSignal.emit()

class UsuarioEliminar(QWidget):
    cancelarSignal = Signal()
    borrarSignal = Signal()

    def __init__(self):
        super().__init__()

        self.__clave = QLabel('Inserte la clave del usuario:')
        self.__lClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar usuario')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bCancelar2 = QPushButton('Cancelar')
        self.__bBorrar = QPushButton('Eliminar')
        self.__infoUsuario = QLabel('Usuario encontrado (simulado)')

        self.__infoUsuario.hide()
        self.__bBorrar.hide()
        self.__bCancelar2.hide()

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lClave)

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bBorrar)
        layoutQH2.addWidget(self.__bCancelar2)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addWidget(self.__infoUsuario)
        layoutQV.addLayout(layoutQH2)
        self.setLayout(layoutQV)

        self.__bBuscar.clicked.connect(self.buscar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bBorrar.clicked.connect(self.borrar)
        self.__bCancelar2.clicked.connect(self.cancelar)

    @Slot()
    def buscar(self):
        clave = self.__lClave.text().strip()
        if not clave:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar una clave.")
            return

        usuario = buscar_usuario(clave)
        if usuario:
            texto = f"""
    <b>Clave:</b> {usuario['clave']}<br>
    <b>Nombre:</b> {usuario['nombre']} {usuario['apellidoP']} {usuario['apellidoM']}<br>
    <b>Edad:</b> {usuario['edad']}<br>
    <b>CURP:</b> {usuario['curp']}<br>
    <b>Correo:</b> {usuario['correo']}<br>
    <b>Rol:</b> {usuario['rol']}
    """
            self.__infoUsuario.setText(texto)
            self.__infoUsuario.setTextFormat(Qt.RichText)
        else:
            self.__infoUsuario.setText("<b>Usuario no encontrado.</b>")

        self.__clave.hide()
        self.__lClave.hide()
        self.__bBuscar.hide()
        self.__bCancelar1.hide()
        self.__bBorrar.show()
        self.__bCancelar2.show()
        self.__infoUsuario.show()

    @Slot()
    def borrar(self):
        resp = QMessageBox.warning(
            self,
            'Confirmar eliminación',
            '¿Seguro que desea eliminar este usuario?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            clave = self.__lClave.text().strip()
            if eliminar_usuario(clave):
                QMessageBox.information(self, 'Eliminado', 'El usuario ha sido eliminado correctamente.')
                self.borrarSignal.emit()
            else:
                QMessageBox.critical(self, 'Error', 'No se pudo eliminar el usuario.')

    @Slot()
    def cancelar(self):
        resp = QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self.cancelarSignal.emit()

class MateriaAgregar(QWidget):
    cancelarSignal = Signal()
    agregarSignal = Signal(dict)

    def __init__(self):
        super().__init__()

        self.__agregarM = QLabel('AGREGAR MATERIA')
        self.__agregarM.setAlignment(Qt.AlignCenter)
        
        self.__nombre = QLabel('Nombre:')
        self.__lNombre = QLineEdit()

        self.__grado = QLabel('Grado:')
        self.__grado.setAlignment(Qt.AlignCenter)

        self.__primero = QRadioButton('1°')
        self.__segundo = QRadioButton('2°')
        self.__tercero = QRadioButton('3°')

        self.__bAgregar = QPushButton('Agregar Materia')
        self.__bCancelar = QPushButton('Cancelar')

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__agregarM)
        layoutForm.addRow(self.__nombre, self.__lNombre)
        layoutForm.addRow(self.__grado)

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__primero)
        layoutQH1.addWidget(self.__segundo)
        layoutQH1.addWidget(self.__tercero)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bAgregar)
        layoutQH2.addWidget(self.__bCancelar)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addLayout(layoutQH2)
        self.setLayout(layoutQV)

        self.__bAgregar.clicked.connect(self.agregar)
        self.__bCancelar.clicked.connect(self.cancelar)
        
    @Slot()
    def agregar(self):
        nombre = self.__lNombre.text().strip()
        grado = 0

        if self.__primero.isChecked():
            grado = 1
        elif self.__segundo.isChecked():
            grado = 2
        elif self.__tercero.isChecked():
            grado = 3

        if not nombre or grado == 0:
            QMessageBox.warning(self, "Campos vacíos", "Debe ingresar el nombre y seleccionar el grado.")
            return

        clave = Materia.generar_clave()
        nueva_materia = Materia(clave, nombre, grado, None, None)

        if insertar_materia(nueva_materia.clave, nueva_materia.nombre, nueva_materia.grado):
            QMessageBox.information(self, "Éxito", "Materia agregada correctamente.")
            self.agregarSignal.emit({
                "clave": nueva_materia.clave,
                "nombre": nueva_materia.nombre,
                "grado": nueva_materia.grado
            })
        else:
            QMessageBox.critical(self, "Error", "No se pudo agregar la materia.")

    @Slot()
    def cancelar(self):
        resp = QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán.',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self.cancelarSignal.emit()

class BuscarMateria(QWidget):
    cancelarSignal = Signal()
    salirSignal = Signal()

    def __init__(self):
        super().__init__()

        self.__clave = QLabel('Inserte la clave de la materia:')
        self.__lClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar materia')
        self.__bCancelar = QPushButton('Cancelar')
        self.__bSalir = QPushButton('Salir')
        self.__infoMateria = QLabel('Materia encontrada')

        self.__infoMateria.hide()
        self.__bSalir.hide()

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lClave)

        layoutBotonesBusqueda = QHBoxLayout()
        layoutBotonesBusqueda.addWidget(self.__bBuscar)
        layoutBotonesBusqueda.addWidget(self.__bCancelar)

        layoutBotonesSalir = QHBoxLayout()
        layoutBotonesSalir.addWidget(self.__bSalir)

        layoutPrincipal = QVBoxLayout()
        layoutPrincipal.addLayout(layoutForm)
        layoutPrincipal.addLayout(layoutBotonesBusqueda)
        layoutPrincipal.addWidget(self.__infoMateria)
        layoutPrincipal.addLayout(layoutBotonesSalir)

        self.setLayout(layoutPrincipal)

        self.__bBuscar.clicked.connect(self.buscar)
        self.__bCancelar.clicked.connect(self.cancelar)
        self.__bSalir.clicked.connect(self.salir)


    @Slot()
    def buscar(self):
        clave = self.__lClave.text().strip()
        if not clave:
            QMessageBox.warning(self, 'Error', 'Debe ingresar una clave para buscar la materia.')
            return

        resultado = buscar_materia(clave)

        if resultado:
            nombre = resultado['nombre']
            grado = resultado['grado']
            self.__infoMateria.setText(f'Materia encontrada:\n\nClave: {clave}\nNombre: {nombre}\nGrado: {grado}')

            self.__clave.hide()
            self.__lClave.hide()
            self.__bBuscar.hide()
            self.__bCancelar.hide()

            self.__infoMateria.show()
            self.__bSalir.show()
        else:
            QMessageBox.information(self, 'No encontrado', f'No se encontró ninguna materia con clave "{clave}".')

    @Slot()
    def cancelar(self):
        resp = QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que deseas cancelar la búsqueda?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self.cancelarSignal.emit()

    @Slot()
    def salir(self):
        self.salirSignal.emit()

class EditarMateria(QWidget):
    cancelarSignal = Signal()
    editarSignal = Signal(dict)

    def __init__(self):
        super().__init__()

        self.__titulo = QLabel('EDITAR MATERIA')
        self.__titulo.setAlignment(Qt.AlignCenter)

        self.__clave = QLabel('Clave:')
        self.__lClave = QLineEdit()

        self.__bBuscar = QPushButton('Buscar')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bCancelar2 = QPushButton('Cancelar')
        self.__bEditar = QPushButton('Editar Materia')

        self.__nombre = QLabel('Nombre:')
        self.__lNombre = QLineEdit()
        self.__grado = QLabel('Grado:')
        self.__grado.setAlignment(Qt.AlignCenter)

        self.__primero = QRadioButton('1°')
        self.__segundo = QRadioButton('2°')
        self.__tercero = QRadioButton('3°')

        self.__nombre.hide()
        self.__lNombre.hide()
        self.__grado.hide()
        self.__primero.hide()
        self.__segundo.hide()
        self.__tercero.hide()
        self.__bEditar.hide()
        self.__bCancelar2.hide()

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__titulo)
        layoutForm.addRow(self.__clave, self.__lClave)

        layoutQH_buscar = QHBoxLayout()
        layoutQH_buscar.addWidget(self.__bBuscar)
        layoutQH_buscar.addWidget(self.__bCancelar1)

        layoutFormEdicion = QFormLayout()
        layoutFormEdicion.addRow(self.__nombre, self.__lNombre)
        layoutFormEdicion.addRow(self.__grado)

        layoutQH_radios = QHBoxLayout()
        layoutQH_radios.addWidget(self.__primero)
        layoutQH_radios.addWidget(self.__segundo)
        layoutQH_radios.addWidget(self.__tercero)

        layoutQH_editar = QHBoxLayout()
        layoutQH_editar.addWidget(self.__bEditar)
        layoutQH_editar.addWidget(self.__bCancelar2)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH_buscar)
        layoutQV.addLayout(layoutFormEdicion)
        layoutQV.addLayout(layoutQH_radios)
        layoutQV.addLayout(layoutQH_editar)
        self.setLayout(layoutQV)

        self.__bBuscar.clicked.connect(self.buscar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bCancelar2.clicked.connect(self.cancelar)
        self.__bEditar.clicked.connect(self.editar)

    @Slot()
    def buscar(self):
        clave = self.__lClave.text().strip()
        if not clave:
            QMessageBox.warning(self, 'Error', 'Debe ingresar la clave para buscar.')
            return

        resultado = buscar_materia(clave)

        if not resultado:
            QMessageBox.information(self, 'No encontrado', f'No se encontró ninguna materia con clave "{clave}".')
            return

        self.__clave_materia = clave

        self.__lNombre.setText(resultado['nombre'])
        if resultado['grado'] == 1:
            self.__primero.setChecked(True)
        elif resultado['grado'] == 2:
            self.__segundo.setChecked(True)
        elif resultado['grado'] == 3:
            self.__tercero.setChecked(True)

        self.__clave.hide()
        self.__lClave.hide()
        self.__bBuscar.hide()
        self.__bCancelar1.hide()

        self.__nombre.show()
        self.__lNombre.show()
        self.__grado.show()
        self.__primero.show()
        self.__segundo.show()
        self.__tercero.show()
        self.__bEditar.show()
        self.__bCancelar2.show()

    @Slot()
    def editar(self):
        nombre = self.__lNombre.text().strip()
        grado = None
        if self.__primero.isChecked(): grado = 1
        elif self.__segundo.isChecked(): grado = 2
        elif self.__tercero.isChecked(): grado = 3

        if not nombre or grado is None:
            QMessageBox.warning(self, 'Datos incompletos', 'Debe completar todos los campos para editar.')
            return

        resp = QMessageBox.question(
            self,
            'Confirmar edición',
            f'¿Seguro que desea editar la materia a "{nombre}" para {grado}°?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )

        if resp == QMessageBox.Yes:
            exito = actualizar_materia(self.__clave_materia, nombre, grado)
            if exito:
                QMessageBox.information(self, 'Éxito', 'Materia editada correctamente.')
                self.editarSignal.emit({"clave": self.__clave_materia, "nombre": nombre, "grado": grado})
            else:
                QMessageBox.critical(self, 'Error', 'No se pudo actualizar la materia.')

    @Slot()
    def cancelar(self):
        resp = QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán.',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self.cancelarSignal.emit()

class BorrarMateria(QWidget):
    cancelarSignal = Signal()
    borrarSignal = Signal(str)

    def __init__(self):
        super().__init__()

        # Widgets
        self.__clave = QLabel('Inserte la clave de la materia:')
        self.__lClave = QLineEdit()

        self.__bBuscar = QPushButton('Buscar materia')
        self.__bCancelarBusqueda = QPushButton('Cancelar')

        self.__infoMateria = QLabel('Materia')
        self.__bBorrar = QPushButton('Eliminar')
        self.__bCancelarBorrado = QPushButton('Cancelar')

        self.__infoMateria.hide()
        self.__bBorrar.hide()
        self.__bCancelarBorrado.hide()

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lClave)

        layoutBotonesBusqueda = QHBoxLayout()
        layoutBotonesBusqueda.addWidget(self.__bBuscar)
        layoutBotonesBusqueda.addWidget(self.__bCancelarBusqueda)

        layoutBotonesBorrado = QHBoxLayout()
        layoutBotonesBorrado.addWidget(self.__bBorrar)
        layoutBotonesBorrado.addWidget(self.__bCancelarBorrado)

        layoutPrincipal = QVBoxLayout()
        layoutPrincipal.addLayout(layoutForm)
        layoutPrincipal.addLayout(layoutBotonesBusqueda)
        layoutPrincipal.addWidget(self.__infoMateria)
        layoutPrincipal.addLayout(layoutBotonesBorrado)

        self.setLayout(layoutPrincipal)

        self.__bBuscar.clicked.connect(self.buscar)
        self.__bBorrar.clicked.connect(self.borrar)
        self.__bCancelarBusqueda.clicked.connect(self.cancelar)
        self.__bCancelarBorrado.clicked.connect(self.cancelar)

    @Slot()
    def buscar(self):
        clave = self.__lClave.text().strip()
        if not clave:
            QMessageBox.warning(self, 'Error', 'Debe ingresar una clave para buscar la materia.')
            return

        resultado = buscar_materia(clave)
        if not resultado:
            QMessageBox.information(self, 'No encontrado', f'No se encontró ninguna materia con clave "{clave}".')
            return

        self.__clave_materia = clave
        self.__infoMateria.setText(f'Materia encontrada:\nNombre: {resultado["nombre"]}\nGrado: {resultado["grado"]}°')

        self.__clave.hide()
        self.__lClave.hide()
        self.__bBuscar.hide()
        self.__bCancelarBusqueda.hide()

        self.__infoMateria.show()
        self.__bBorrar.show()
        self.__bCancelarBorrado.show()

    @Slot()
    def borrar(self):
        clave = self.__clave_materia
        resp = QMessageBox.warning(
            self,
            'Confirmar eliminación',
            f'¿Seguro que desea eliminar la materia con clave "{clave}"?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if resp == QMessageBox.Yes:
            exito = eliminar_materia(clave)
            if exito:
                QMessageBox.information(self, 'Éxito', 'Materia eliminada correctamente.')
                self.borrarSignal.emit(clave)
            else:
                QMessageBox.critical(self, 'Error', 'No se pudo eliminar la materia. Verifique restricciones.')

    @Slot()
    def cancelar(self):
        resp = QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que deseas cancelar la operación?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self.cancelarSignal.emit()
    
class ReporteAgregar(QWidget):
    subirSignal = Signal()
    cancelarSignal = Signal()

    def __init__(self):
        super().__init__()

        #Widgets
        self.__titulo = QLabel('Ingrese el asunto: ')
        self.__tituloT=QLineEdit()
        self.__descripcion = QLabel('Descripción: ')
        self.__descripcionT=QTextEdit()
        self.__claveMateria=QLabel("Clave de la materia:")
        self.__claveMateriaT=QLineEdit()
        self.__claveAlumno=QLabel("Clave alumno:")
        self.__claveAlumnoT=QLineEdit()
        self.__bSubir = QPushButton('Enviar reporte')
        self.__bCancelar = QPushButton('Cancelar')

        # Layout Formulario
        layoutForm = QFormLayout()
        layoutForm.addRow(self.__claveAlumno,self.__claveAlumnoT)
        layoutForm.addRow(self.__claveMateria,self.__claveMateriaT)
        layoutForm.addRow(self.__titulo,self.__tituloT)
        layoutForm.addRow(self.__descripcion)
        layoutForm.addRow(self.__descripcionT)

        # Layout Botones
        layoutQH = QHBoxLayout()
        layoutQH.addWidget(self.__bSubir)
        layoutQH.addWidget(self.__bCancelar)

        #Layout Principal
        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH)
        self.setLayout(layoutQV)

        #Conexiones 
        self.__bSubir.clicked.connect(self.subir)
        self.__bCancelar.clicked.connect(self.cancelar)
    
    @Slot()
    def subir(self):
        if QMessageBox.information(
            self,
            '',
            'Verifica que los datos sean correctos',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Ok
        ) == QMessageBox.Ok:
            self.subirSignal.emit()

        alumno=self.__claveAlumnoT.text()
        materia=self.__claveMateriaT.text()
        asunto=self.__tituloT.text()
        descripcion=self.__descripcionT.toPlainText()
        fecha=datetime.now() 
      
        reporte= Reporte(fecha, asunto, descripcion,alumno,materia)
        exito= insertar_reporte(
            reporte.fecha,
            reporte.asunto,
            reporte.descripcion,
            reporte.clave_alumno,
            reporte.clave_materia)

        if exito:
            QMessageBox.information(self, 'Éxito', 'Reporte fue registrado correctamente.')
            self.subirSignal.emit()
        else:
            QMessageBox.critical(self, 'Error', 'No se pudo registrar el reporte.')


    @Slot()
    def cancelar(self):
        if QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Cancel
        ) == QMessageBox.Ok:
            self.cancelarSignal.emit()
    
class ReporteBorrar(QWidget):
    borrarSignal = Signal()
    cancelarSignal = Signal()
    
    def __init__(self):
        super().__init__()
        
        # Widgets
        self.__clave = QLabel('Inserte el numero de reporte:')
        self.__lClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar reporte')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bCancelar2 = QPushButton('Cancelar')
        self.__bBorrar = QPushButton('Eliminar')
        self.__infoReporte = QLabel('Reporte')
        self.__infoReporte.hide()
        self.__bBorrar.hide()
        self.__bCancelar2.hide()
        
        # Layout formulario
        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lClave)

        # Layout botones buscar
        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        # Layout botones mostrar
        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bBorrar)
        layoutQH2.addWidget(self.__bCancelar2)

        # Layout principal
        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addWidget(self.__infoReporte)
        layoutQV.addLayout(layoutQH2)
        self.setLayout(layoutQV)

        # Conexiones
        
        self.__bBuscar.clicked.connect(self.buscar)
        self.__bBorrar.clicked.connect(self.borrar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bCancelar2.clicked.connect(self.cancelar)

    @Slot()
    def buscar(self):
        clave = self.__lClave.text().strip()
        
        if not clave:
            QMessageBox.warning(self, "Advertencia", "Por favor ingresa un número de reporte.")
            return

        reporte = buscar_reporte(clave)
        if reporte:
            texto = f"""
                ID: {reporte["id"]}
                Fecha: {reporte["fecha"]}
                Asunto: {reporte["asunto"]}
                Clave alumno: {reporte["claveAlumno"]}
                Clave materia: {reporte["claveMateria"]}
                Descripción: {reporte["descripcion"]}
                """
            self.__infoReporte.setText(texto.strip())
            

        self.__clave.hide()
        self.__lClave.hide()
        self.__bBuscar.hide()
        self.__bCancelar1.hide()
        self.__infoReporte.show()
        self.__bBorrar.show()
        self.__bCancelar2.show()
    
    @Slot()
    def borrar(self):
        resp=QMessageBox.information(
            
            self,
            '',
            'Seguro que deseas borrar el reporte',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Ok)
        
        clave=self.__lClave.text()
      
        if QMessageBox.Ok==resp:
            clave = self.__lClave.text().strip()
            if borrar_reporte(clave):
                QMessageBox.information(self, 'Eliminado', 'El reporte ha sido eliminado correctamente.')
                self.borrarSignal.emit()
            else:
                QMessageBox.critical(self, 'Error', 'No se pudo eliminar el reporte.')

    
    @Slot()
    def cancelar(self):
        resp = QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que deseas cancelar la operación?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self.cancelarSignal.emit()

class ReporteBuscar(QWidget):
    cancelarSignal = Signal()
    salirSignal=Signal()
    
    def __init__(self):
        super().__init__()
        self.__clave = QLabel('Inserte el numero de reporte:')
        self.__lClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar reporte')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bSalir = QPushButton('Salir')
        self.__infoReporte = QLabel('Reporte')
        self.__infoReporte.hide()
        self.__bSalir.hide()
        
        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lClave)

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bSalir)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addWidget(self.__infoReporte)
        layoutQV.addLayout(layoutQH2)
        
        self.setLayout(layoutQV)

        self.__bBuscar.clicked.connect(self.buscar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bSalir.clicked.connect(self.salir)

    
    @Slot()
    def buscar(self):
        
        clave = self.__lClave.text().strip()
        
        if not clave:
            QMessageBox.warning(self, "Advertencia", "Por favor ingresa un número de reporte.")
            return

        reporte = buscar_reporte(clave)
        if reporte:
            texto = f"""
                ID: {reporte["id"]}
                Fecha: {reporte["fecha"]}
                Asunto: {reporte["asunto"]}
                Clave alumno: {reporte["claveAlumno"]}
                Clave materia: {reporte["claveMateria"]}
                Descripción: {reporte["descripcion"]}
                """
            self.__infoReporte.setText(texto.strip())
            self.__infoReporte.show()

            self.__clave.hide()
            self.__lClave.hide()
            self.__bBuscar.hide()
            self.__bCancelar1.hide()
            self.__bSalir.show()
                
        else:
            QMessageBox.critical(self, 'Error', 'No se puede mostrar el reporte.')

    @Slot ()
    def cancelar(self):
        resp=QMessageBox.question(
            self,
            'Confirmar',
            "¿Deseas cancelar la busqueda?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp==QMessageBox.Yes:
            self.cancelarSignal.emit()
    
    @Slot()
    def salir(self):
        self.salirSignal.emit()

class ReporteMostrar(QWidget):
    cancelarSignal=Signal()
    salirSignal=Signal()

    def __init__(self):
        super().__init__()

        #Widgets 
        self.__clave =QLabel('Inserte el numero del alumno:')
        self.__lclave=QLineEdit()
        self.__bBuscar=QPushButton('Mostrar reporte')
        self.__bCancelar1=QPushButton('Cancelar')
        self.__bSalir=QPushButton('Salir')
        self.__infoReporte=QLabel('Descripcion')
        self.__infoReporte.hide()
        self.__bSalir.hide()
        #Layout formulario 
        layoutForm=QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lclave)

        #Layout botones buscar y cancelar 
        layoutQH1=QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        #Layout botón salir 
        layoutQH2=QHBoxLayout()
        layoutQH2.addWidget(self.__bSalir)

        #Layout principal 
        layoutQV=QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addWidget(self.__infoReporte)
        layoutQV.addLayout(layoutQH2)
        self.setLayout(layoutQV)
        
        #Conexiones
        self.__bBuscar.clicked.connect(self.buscar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bSalir.clicked.connect(self.salir)

    @Slot()
    def buscar(self):
        clave = self.__lclave.text().strip()

        if not clave:
            QMessageBox.warning(self, "Advertencia", "Por favor ingresa un número de reporte.")
            return

        reportes = mostrar_reporte(clave)  # Debe devolver lista o None

        if reportes:
            texto = ""
            for reporte in reportes:
                texto += (
                    f"ID: {reporte['id']}\n"
                    f"Fecha: {reporte['fecha']}\n"
                    f"Asunto: {reporte['asunto']}\n"
                    f"Clave alumno: {reporte['claveAlumno']}\n"
                    f"Clave materia: {reporte['claveMateria']}\n"
                    f"Descripción: {reporte['descripcion']}\n"
                    "-------------------------\n"
                )
            self.__infoReporte.setText(texto.strip())
            self.__infoReporte.show()

            self.__clave.hide()
            self.__lclave.hide()
            self.__bBuscar.hide()
            self.__bCancelar1.hide()
            self.__bSalir.show()
        else:
            QMessageBox.critical(self, 'Error', 'No se puede mostrar el reporte.')
   
    @Slot()
    def cancelar(self):
        resp=QMessageBox.question(
            self,
            'Confirmar',
            "¿Deseas cancelar la operación? ",
            QMessageBox.Yes|QMessageBox.No,
            QMessageBox.No 
        )

        if resp==QMessageBox.Yes:
            self.cancelarSignal.emit()


    @Slot()
    def salir(self):
        self.salirSignal.emit()

class AsignarMateriaProfesor(QWidget):
    cancelarSignal = Signal()
    salirSignal=Signal()
    
    def __init__(self):
        super().__init__()
        self.__label = QLabel('ASIGNACIÓN DE PROFESORES')
        self.__label.setAlignment(Qt.AlignCenter)
        self.__clave = QLabel('Profesor: ')
        self.__lClave = QLineEdit()
        self.__materia = QLabel('Materia: ')
        self.__lMateria = QLineEdit()
        self.__listaProfesores = QPushButton('Profesores')
        self.__listaMaterias = QPushButton('Materias')
        self.__grupo = QLabel('GRUPO')
        self.__grupo.setAlignment(Qt.AlignCenter)
        self.__grupoA = QRadioButton('A')
        self.__grupoB = QRadioButton('B')
        self.__grupoC = QRadioButton('C')
        self.__asignar = QPushButton('Asignar')
        self.__cancelar = QPushButton('Cancelar')

        layoutQH0 = QHBoxLayout()
        layoutQH0.addWidget(self.__clave)
        layoutQH0.addWidget(self.__lClave)
        layoutQH0.addWidget(self.__listaProfesores)

        layoutQH01 = QHBoxLayout()
        layoutQH01.addWidget(self.__materia)
        layoutQH01.addWidget(self.__lMateria)
        layoutQH01.addWidget(self.__listaMaterias)

        layoutForm = QFormLayout()
        layoutForm.addRow(self.__label)
        layoutForm.addRow(layoutQH0)
        layoutForm.addRow(layoutQH01)
        layoutForm.addRow(self.__grupo)

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__grupoA)
        layoutQH1.addWidget(self.__grupoB)
        layoutQH1.addWidget(self.__grupoC)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__asignar)
        layoutQH2.addWidget(self.__cancelar)

        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addLayout(layoutQH2)

        self.setLayout(layoutQV)

        self.__asignar.clicked.connect(self.asignar)
        self.__cancelar.clicked.connect(self.cancelar)
        self.__listaMaterias.clicked.connect(self.listaMaterias)
        self.__listaProfesores.clicked.connect(self.listaProfesores)

    def mostrar_tabla(self, datos, columnas, titulo, mapeo=None):
        ventana = QDialog(self)
        ventana.setWindowTitle(titulo)
        tabla = QTableWidget(len(datos), len(columnas))
        tabla.setHorizontalHeaderLabels(columnas)
        tabla.setEditTriggers(QTableWidget.NoEditTriggers)

        for fila_idx, fila in enumerate(datos):
            for col_idx, encabezado in enumerate(columnas):
                clave = mapeo[encabezado] if mapeo else encabezado.lower()
                valor = fila.get(clave, '')
                tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        tabla.resizeColumnsToContents()
        layout = QVBoxLayout()
        layout.addWidget(tabla)
        ventana.setLayout(layout)
        ventana.resize(500, 300)
        ventana.exec()

    @Slot()
    def asignar(self):
        from Conexion import buscar_usuario, buscar_materia, asignar_materia_profesor

        clave_profesor = self.__lClave.text().strip()
        clave_materia = self.__lMateria.text().strip()
        grupo = None

        if self.__grupoA.isChecked():
            grupo = 'A'
        elif self.__grupoB.isChecked():
            grupo = 'B'
        elif self.__grupoC.isChecked():
            grupo = 'C'

        if not clave_profesor or not clave_materia or not grupo:
            QMessageBox.warning(self, "Datos incompletos", "Debes llenar todos los campos y seleccionar un grupo.")
            return

        profesor = buscar_usuario(clave_profesor)
        if not profesor or not clave_profesor.startswith('P'):
            QMessageBox.warning(self, "Error", "El profesor no existe o la clave no es válida.")
            return

        materia = buscar_materia(clave_materia)
        if not materia:
            QMessageBox.warning(self, "Error", "La materia no existe.")
            return

        if asignar_materia_profesor(clave_profesor, clave_materia, grupo):
            QMessageBox.information(self, "Éxito", "Materia asignada correctamente al profesor.")
            self.salirSignal.emit()
        else:
            QMessageBox.critical(self, "Error", "No se pudo asignar la materia. Puede que ya esté asignada.")
    
    @Slot()
    def listaProfesores(self):
        from Conexion import obtener_usuarios_por_prefijo
        profesores = obtener_usuarios_por_prefijo('P')
        if not profesores:
            QMessageBox.information(self, "Información", "No hay profesores registrados.")
            return

        columnas = ['CLAVE', 'NOMBRE', 'APELLIDO PATERNO', 'APELLIDO MATERNO']
        mapeo = {
            'CLAVE': 'clave',
            'NOMBRE': 'nombre',
            'APELLIDO PATERNO': 'apellidoP',
            'APELLIDO MATERNO': 'apellidoM'
        }
        self.mostrar_tabla(profesores, columnas, "Profesores disponibles", mapeo)

    @Slot()
    def listaMaterias(self):
        from Conexion import obtener_materias
        materias = obtener_materias()
        if not materias:
            QMessageBox.information(self, "Información", "No hay materias registradas.")
            return

        columnas = ['CLAVE', 'NOMBRE', 'GRADO']
        mapeo = {
            'CLAVE': 'clave',
            'NOMBRE': 'nombre',
            'GRADO': 'grado'
        }
        self.mostrar_tabla(materias, columnas, "Materias disponibles", mapeo)


    @Slot()
    def cancelar(self):
        if QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Cancel
        ) == QMessageBox.Ok:
            self.cancelarSignal.emit()
    
class AsignarGrupoAlumno(QWidget):
    cancelarSignal=Signal()
    
    def __init__(self):
        super().__init__()
        self.__titulo=QLabel("ASIGNACIÓN DE ALUMNOS")
        self.__titulo.setAlignment(Qt.AlignCenter)
        self.__alumnoE=QLabel("Alumno:")
        self.__alumnoT=QLineEdit()
        self.__gradoE=QLabel("Grado")
        self.__gradoE.setAlignment(Qt.AlignCenter)
        self.__grado1 = QRadioButton('1')
        self.__grado2 = QRadioButton('2')
        self.__grado3 = QRadioButton('3')
        self.__grupoE=QLabel("Grupo")
        self.__grupoE.setAlignment(Qt.AlignCenter)
        self.__grupoA = QRadioButton('A')
        self.__grupoB = QRadioButton('B')
        self.__grupoC = QRadioButton('C')
        self.__asignar = QPushButton('Asignar')
        self.__cancelar = QPushButton('Cancelar')

        self.__grupoGrado = QButtonGroup(self)
        self.__grupoGrado.addButton(self.__grado1)
        self.__grupoGrado.addButton(self.__grado2)
        self.__grupoGrado.addButton(self.__grado3)

        self.__grupoGrupo = QButtonGroup(self)
        self.__grupoGrupo.addButton(self.__grupoA)
        self.__grupoGrupo.addButton(self.__grupoB)
        self.__grupoGrupo.addButton(self.__grupoC)

        self.__formulario=QFormLayout()
        self.__formulario.addRow(self.__titulo)
        self.__formulario.addRow(self.__alumnoE,self.__alumnoT)
        
        
        self.__layoutHGRA=QHBoxLayout()
        self.__layoutHGRA.addWidget(self.__gradoE)

        self.__layoutGrado=QHBoxLayout()
        self.__layoutGrado.addWidget(self.__grado1)
        self.__layoutGrado.addWidget(self.__grado2)
        self.__layoutGrado.addWidget(self.__grado3)
        

        self.__layoutHGRU=QHBoxLayout()
        self.__layoutHGRU.addWidget(self.__grupoE)

        self.__layoutGrupo=QHBoxLayout()
        self.__layoutGrupo.addWidget(self.__grupoA)
        self.__layoutGrupo.addWidget(self.__grupoB)
        self.__layoutGrupo.addWidget(self.__grupoC)
        

        self.__layoutBotones=QHBoxLayout()
        self.__layoutBotones.addWidget(self.__asignar)
        self.__layoutBotones.addWidget(self.__cancelar)
        

        self.__layoutV=QVBoxLayout()
        self.__layoutV.addLayout(self.__formulario)
        self.__layoutV.addLayout(self.__layoutHGRA)
        self.__layoutV.addLayout(self.__layoutGrado)
        self.__layoutV.addLayout(self.__layoutHGRU)
        self.__layoutV.addLayout(self.__layoutGrupo)
        self.__layoutV.addLayout(self.__layoutBotones)
        self.__layoutV.addStretch()
        

        self.setLayout(self.__layoutV)
        self.__asignar.clicked.connect(self.asignar)
        self.__cancelar.clicked.connect(self.cancelar)

    @Slot()
    def asignar(self):
        clave_alumno=self.__alumnoT.text().strip()
        grado = None
        if self.__grado1.isChecked():
            grado = '1'
        elif self.__grado2.isChecked():
            grado = '2'
        elif self.__grado3.isChecked():
            grado = '3'

        grupo = None
        if self.__grupoA.isChecked():
            grupo = 'A'
        elif self.__grupoB.isChecked():
            grupo = 'B'
        elif self.__grupoC.isChecked():
            grupo = 'C'


        if not grado or not grupo:
            QMessageBox.warning(self, "Advertencia", "Por favor, selecciona un grado.")
            return
        
        grupoA= GrupoAlumno(clave_alumno, grado, grupo)
        exito= insertar_grupo_alumno(
            grupoA.clave_alumno,
            grupoA.grado,
            grupoA.grupo)

        if exito:
            QMessageBox.information(self, 'Éxito', 'Reporte fue registrado correctamente.')
            self.subirSignal.emit()
        else:
            QMessageBox.critical(self, 'Error', 'No se pudo registrar el reporte.')
        
        resp = QMessageBox.question(
                self,
                'Asignar',
                '¿Está seguro?',
                QMessageBox.Yes | QMessageBox.Cancel,
                QMessageBox.Cancel
            )

        if resp==QMessageBox.Yes:
            QMessageBox.information(self,'El alumno se asigno correctamente')
            
        

    @Slot()
    def cancelar(self):
        resp=QMessageBox.question(
            self,
            'Confirmar',
            "¿Deseas cancelar la operación? ",
            QMessageBox.Yes|QMessageBox.No,
            QMessageBox.No 
        )

        if resp==QMessageBox.Yes:
            self.cancelarSignal.emit()

class HorarioAgregar(QWidget):
    agregarSignal = Signal()
    cancelarSignal = Signal()

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Agregar Horario")

        # Widgets
        self._clave_materia = QLineEdit()
        self._clave_profesor = QLineEdit()
        self._dia = QComboBox()
        self._dia.addItems(["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"])
        self._hora_inicio = QTimeEdit()
        self._hora_fin = QTimeEdit()
        self._grupo = QLineEdit()

        self._bAgregar = QPushButton("Agregar")
        self._bCancelar = QPushButton("Cancelar")

        # Layout
        form = QFormLayout()
        form.addRow("Clave Materia:", self._clave_materia)
        form.addRow("Clave Profesor:", self._clave_profesor)
        form.addRow("Día:", self._dia)
        form.addRow("Hora Inicio:", self._hora_inicio)
        form.addRow("Hora Fin:", self._hora_fin)
        form.addRow("Grupo:", self._grupo)

        buttons = QHBoxLayout()
        buttons.addWidget(self._bAgregar)
        buttons.addWidget(self._bCancelar)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addLayout(buttons)
        self.setLayout(layout)

        # Conexiones
        self._bAgregar.clicked.connect(self.insertar_horario)
        self._bCancelar.clicked.connect(self.cancelarSignal)

    @Slot()
    def insertar_horario(self):
        from Conexion import insertar_horario
        datos = {
            "materia": self._clave_materia.text().strip(),
            "profesor": self._clave_profesor.text().strip(),
            "dia": self._dia.currentText(),
            "inicio": self._hora_inicio.time().toString("HH:mm:ss"),
            "fin": self._hora_fin.time().toString("HH:mm:ss"),
            "grupo": self._grupo.text().strip()
        }

        if not all(datos.values()):
            QMessageBox.warning(self, "Campos Vacíos", "Todos los campos deben estar llenos.")
            return

        if insertar_horario(**datos):
            QMessageBox.information(self, "Éxito", "Horario agregado correctamente.")
            self.agregarSignal.emit()
        else:
            QMessageBox.critical(self, "Error", "No se pudo agregar el horario.")
            
class HorarioConsultar(QWidget):
    salirSignal = Signal()
    cancelarSignal = Signal()

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Consultar Horarios")

        self._tabla = QTableWidget()
        self._tabla.setColumnCount(6)
        self._tabla.setHorizontalHeaderLabels(["Materia", "Profesor", "Día", "Inicio", "Fin", "Grupo"])
        self._tabla.horizontalHeader().setStretchLastSection(True)

        self._bActualizar = QPushButton("Actualizar")
        self._bCancelar = QPushButton("Salir")

        botones = QHBoxLayout()
        botones.addWidget(self._bActualizar)
        botones.addWidget(self._bCancelar)

        layout = QVBoxLayout()
        layout.addWidget(self._tabla)
        layout.addLayout(botones)
        self.setLayout(layout)

        self._bActualizar.clicked.connect(self.cargar_horarios)
        self._bCancelar.clicked.connect(self.salirSignal)

        self.cargar_horarios()

    @Slot()
    def cargar_horarios(self):
        from Conexion import consultar_horarios
        self._tabla.setRowCount(0)
        datos = consultar_horarios()
        for fila in datos:
            row = self._tabla.rowCount()
            self._tabla.insertRow(row)
            for col, valor in enumerate(fila):
                self._tabla.setItem(row, col, QTableWidgetItem(str(valor)))

class HorarioEditar(QWidget):
    editarSignal = Signal()
    cancelarSignal = Signal()

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Editar Horario")

        self._id = QLineEdit()
        self._clave_materia = QLineEdit()
        self._clave_profesor = QLineEdit()
        self._dia = QComboBox()
        self._dia.addItems(["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"])
        self._hora_inicio = QTimeEdit()
        self._hora_fin = QTimeEdit()
        self._grupo = QLineEdit()

        self._bEditar = QPushButton("Editar")
        self._bCancelar = QPushButton("Cancelar")

        form = QFormLayout()
        form.addRow("ID Horario:", self._id)
        form.addRow("Clave Materia:", self._clave_materia)
        form.addRow("Clave Profesor:", self._clave_profesor)
        form.addRow("Día:", self._dia)
        form.addRow("Hora Inicio:", self._hora_inicio)
        form.addRow("Hora Fin:", self._hora_fin)
        form.addRow("Grupo:", self._grupo)

        botones = QHBoxLayout()
        botones.addWidget(self._bEditar)
        botones.addWidget(self._bCancelar)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addLayout(botones)
        self.setLayout(layout)

        self._bEditar.clicked.connect(self.editar_horario)
        self._bCancelar.clicked.connect(self.cancelarSignal)

    @Slot()
    def editar_horario(self):
        from Conexion import actualizar_horario
        try:
            id_horario = int(self._id.text())
            datos = {
                "materia": self._clave_materia.text().strip(),
                "profesor": self._clave_profesor.text().strip(),
                "dia": self._dia.currentText(),
                "inicio": self._hora_inicio.time().toString("HH:mm:ss"),
                "fin": self._hora_fin.time().toString("HH:mm:ss"),
                "grupo": self._grupo.text().strip()
            }

            if not all([id_horario, *datos.values()]):
                QMessageBox.warning(self, "Campos vacíos", "Todos los campos deben estar completos.")
                return

            if actualizar_horario(id_horario, **datos):
                QMessageBox.information(self, "Éxito", "Horario actualizado correctamente.")
                self.editarSignal.emit()
            else:
                QMessageBox.critical(self, "Error", "No se pudo actualizar el horario.")
        except ValueError:
            QMessageBox.warning(self, "Error de formato", "El ID debe ser un número entero.")
            
class HorarioEliminar(QWidget):
    eliminarSignal = Signal()
    cancelarSignal = Signal()

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Eliminar Horario")

        self._id = QLineEdit()
        self._bEliminar = QPushButton("Eliminar")
        self._bCancelar = QPushButton("Cancelar")

        form = QFormLayout()
        form.addRow("ID Horario a eliminar:", self._id)

        botones = QHBoxLayout()
        botones.addWidget(self._bEliminar)
        botones.addWidget(self._bCancelar)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addLayout(botones)
        self.setLayout(layout)

        self._bEliminar.clicked.connect(self.eliminar_horario)
        self._bCancelar.clicked.connect(self.cancelarSignal)

    @Slot()
    def eliminar_horario(self):
        from Conexion import eliminar_horario
        try:
            id_horario = int(self._id.text())
            if eliminar_horario(id_horario):
                QMessageBox.information(self, "Éxito", "Horario eliminado correctamente.")
                self.eliminarSignal.emit()
            else:
                QMessageBox.critical(self, "Error", "No se pudo eliminar el horario.")
        except ValueError:
            QMessageBox.warning(self, "Error de formato", "El ID debe ser un número entero.")
            
if __name__ == '__main__':
    app = QApplication()
    ventana = BorrarMateria()
    ventana.show()
    app.exec()

"""

PLANTILLA

class ReporteBorrar(QWidget):
    subirSignal = Signal()
    cancelarSignal = Signal()
    
    def __init__(self):
        super().__init__()
        
        # Widgets
        
        # Layout formulario
        

        # Layout botones
        

        # Layout principal
        

        # Conexiones
        self.__bSubir.clicked.connect(self.subir)
        self.__bCancelar.clicked.connect(self.cancelar)

    @Slot()
    def subir(self):
        if QMessageBox.information(
            self,
            '',
            'Verifica que los datos sean correctos',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Ok
        ) == QMessageBox.Ok:
            self.subirSignal.emit()

    @Slot()
    def cancelar(self):
        if QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Cancel
        ) == QMessageBox.Ok:
            self.cancelarSignal.emit()
"""
