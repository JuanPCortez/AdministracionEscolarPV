import sys

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
from datetime import datetime
from Usuarios.Reporte import Reporte
from Conexion import *


from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

class ConsularGrupos(QWidget):
    consultarSignal = Signal()
    salirSignal=Signal()
    cancelarSignal=Signal()

    def __init__(self, clave_profesor):
        super().__init__()
        self.__clave_profesor = clave_profesor
        self.__consular = QLabel('CONSULTAR GRUPO')
        self.__consular.setAlignment(Qt.AlignCenter)
        self.__grado = QLabel('Grado:')
        self.__primero = QRadioButton('1°')
        self.__segundo = QRadioButton('2°')
        self.__tercero = QRadioButton('3°')

        self.__grupo = QLabel('Grupo:')
        self.__grupoA = QRadioButton('A')
        self.__grupoB = QRadioButton('B')
        self.__grupoC = QRadioButton('C')

        self.__grupo_grado = QButtonGroup(self)
        self.__grupo_grado.addButton(self.__primero)
        self.__grupo_grado.addButton(self.__segundo)
        self.__grupo_grado.addButton(self.__tercero)

        self.__grupo_grupo = QButtonGroup(self)
        self.__grupo_grupo.addButton(self.__grupoA)
        self.__grupo_grupo.addButton(self.__grupoB)
        self.__grupo_grupo.addButton(self.__grupoC)

        self.__tabla=QTableWidget()
        self.__tabla.setColumnCount(4)
        self.__tabla.setHorizontalHeaderLabels(["Clave materia", "Nombre materia", "Grupo","Alumnos"])
        self.__tabla.hide()

        self.__bBuscar = QPushButton('Buscar grupo')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bSalir = QPushButton('Salir')
        self.__infoGrupo = QLabel('Clave, nombre, #al, salon')
        self.__infoGrupo.hide()
        self.__bSalir.hide()

        layoutQV1 = QVBoxLayout()
        layoutQV1.addWidget(self.__grado)
        layoutQV1.addWidget(self.__primero)
        layoutQV1.addWidget(self.__segundo)
        layoutQV1.addWidget(self.__tercero)

        layoutQV2 = QVBoxLayout()
        layoutQV2.addWidget(self.__grupo)
        layoutQV2.addWidget(self.__grupoA)
        layoutQV2.addWidget(self.__grupoB)
        layoutQV2.addWidget(self.__grupoC)

        layoutQH3 = QHBoxLayout()
        layoutQH3.addLayout(layoutQV1)
        layoutQH3.addLayout(layoutQV2)
     

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bSalir)

        layoutQV = QVBoxLayout()
        layoutQV.addWidget(self.__consular)
        layoutQV.addWidget(self.__infoGrupo)
        layoutQV.addLayout(layoutQH3)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addLayout(layoutQH2)
        layoutQV.addWidget(self.__tabla)
        self.setLayout(layoutQV)
        
        self.__bBuscar.clicked.connect(self.buscar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bSalir.clicked.connect(self.salir)

    
    @Slot()
    def buscar(self):
        from Conexion import crear_conexion

        if self.__primero.isChecked():
            grado=1
        elif self.__segundo.isChecked():
            grado=2
        elif self.__tercero.isChecked():
           grado=3

        if self.__grupoA.isChecked():
            grupo='A'
        elif self.__grupoB.isChecked():
            grupo='B'
        elif self.__grupoC.isChecked():
            grupo='C'


        try:
            conexion = crear_conexion()
            cursor = conexion.cursor(dictionary=True)

            query = """
                SELECT pmg.clave_materia, m.nombre AS nombre_materia, pmg.grupo, count(a.clave_alumno) as alumnos
                FROM profesor_materia_grupo pmg
                JOIN materia  as m ON pmg.clave_materia = m.clave
                JOIN grupo_alumno as a on m.grado=a.grado
                WHERE pmg.clave_profesor = %s and m.grado=%s
                GROUP BY pmg.clave_materia,pmg.grupo
                HAVING pmg.grupo=%s
            """
            cursor.execute(query, (self.__clave_profesor,grado,grupo))

            datos = cursor.fetchall()
            cursor.close()
            conexion.close()

            

            self.__tabla.setRowCount(len(datos))
            for i, fila in enumerate(datos):
                self.__tabla.setItem(i, 0, QTableWidgetItem(fila["clave_materia"]))
                self.__tabla.setItem(i, 1, QTableWidgetItem(fila["nombre_materia"]))
                self.__tabla.setItem(i, 2, QTableWidgetItem(fila["grupo"]))
                self.__tabla.setItem(i, 3, QTableWidgetItem(str(fila["alumnos"])))

            self.__tabla.show()
            self.__bSalir.show()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Ocurrió un error al consultar: {e}")

    @Slot()
    def cancelar(self):
        resp=QMessageBox.question(
            self,
            'Comfirmar',
            "¿Deseas cancelar la operación? ",
            QMessageBox.Yes|QMessageBox.No,
            QMessageBox.No 
        )

        if resp==QMessageBox.Yes:
            self.cancelarSignal.emit()

    @Slot()
    def salir(self):
        self.salirSignal.emit()

        
class ListaGrupo(QWidget):
    listaSignal = Signal()
    cancelarSignal=Signal()
    salirSignal=Signal()

    def __init__(self,clave_profesor):
        super().__init__()
        self.__clave_profesor = clave_profesor
        self.__consular = QLabel('CONSULTAR GRUPO')
        self.__consular.setAlignment(Qt.AlignCenter)
        
        self.__grado = QLabel('Grado:')
        self.__primero = QRadioButton('1°')
        self.__segundo = QRadioButton('2°')
        self.__tercero = QRadioButton('3°')

        self.__grupo = QLabel('Grupo:')
        self.__grupoA = QRadioButton('A')
        self.__grupoB = QRadioButton('B')
        self.__grupoC = QRadioButton('C')

        self.__grupo_grado = QButtonGroup(self)
        self.__grupo_grado.addButton(self.__primero)
        self.__grupo_grado.addButton(self.__segundo)
        self.__grupo_grado.addButton(self.__tercero)

        self.__grupo_grupo = QButtonGroup(self)
        self.__grupo_grupo.addButton(self.__grupoA)
        self.__grupo_grupo.addButton(self.__grupoB)
        self.__grupo_grupo.addButton(self.__grupoC)

        self.tabla = QTableWidget(0,4)
        self.tabla.setHorizontalHeaderLabels(['CLAVE','NOMBRE','APELLIDO PATERNO','APELLIDO MATERNO'])
        self.tabla.hide()

        self.__bBuscarG = QPushButton('Buscar grupo')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bSalir = QPushButton('Salir')
        
        self.__bSalir.hide()
        
        self.__cmbMateria = QComboBox()
        self.__cmbHorario = QComboBox()
        self.__bBuscarA= QPushButton("Buscar alumnos")
        self.__bBuscarA.hide()
        
        # Layout de materia y horario
        layoutMateriaHorario = QVBoxLayout()
        layoutMateriaHorario.addWidget(QLabel("Materia:"))
        layoutMateriaHorario.addWidget(self.__cmbMateria)
        layoutMateriaHorario.addWidget(QLabel("Horario:"))
        layoutMateriaHorario.addWidget(self.__cmbHorario)
        self

        # Layout de grado y grupo
        layoutQV1 = QVBoxLayout()
        layoutQV1.addWidget(self.__grado)
        layoutQV1.addWidget(self.__primero)
        layoutQV1.addWidget(self.__segundo)
        layoutQV1.addWidget(self.__tercero)

        layoutQV2 = QVBoxLayout()
        layoutQV2.addWidget(self.__grupo)
        layoutQV2.addWidget(self.__grupoA)
        layoutQV2.addWidget(self.__grupoB)
        layoutQV2.addWidget(self.__grupoC)

        layoutQH3 = QHBoxLayout()
        layoutQH3.addLayout(layoutQV1)
        layoutQH3.addLayout(layoutQV2)

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscarG)
        layoutQH1.addWidget(self.__bCancelar1)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bSalir)
        layoutQH2.addWidget(self.__bBuscarA)

        # Layout principal
        layoutPrincipal = QVBoxLayout()
        layoutPrincipal.addWidget(self.__consular)
        layoutPrincipal.addLayout(layoutMateriaHorario)
        layoutPrincipal.addLayout(layoutQH3)
        layoutPrincipal.addWidget(self.tabla)
        layoutPrincipal.addLayout(layoutQH1)
        layoutPrincipal.addLayout(layoutQH2)

        self.setLayout(layoutPrincipal)

        
        self.__bBuscarG.clicked.connect(self.listar_alumnos)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bSalir.clicked.connect(self.salir)
    
    def cargar_materias(self, clave_profesor,grupo,grado):
        from Conexion import crear_conexion
        conexion = crear_conexion()
        cursor = conexion.cursor(dictionary=True) 

        consulta = """
            SELECT m.clave, m.nombre
            FROM profesor_materia_grupo as pmg
            JOIN materia  as m ON pmg.clave_materia = m.clave
            WHERE pmg.clave_profesor = %s
            AND pmg.grupo = %s
            AND m.grado = %s
        """
        cursor.execute(consulta, (clave_profesor,grupo,grado))
        materias = cursor.fetchall()
        self.__cmbMateria.clear() 
        
        for materia in materias:
            clave = materia["clave"]
            nombre = materia["nombre"]
            self.__cmbMateria.addItem(f"{clave} - {nombre}")
        cursor.close()
        conexion.close()
    

    def listar_alumnos(self):
        from Conexion import crear_conexion
        clave_profesor = self.__clave_profesor  # Asignada al iniciar sesión
        #clave_materia = self.combo_materia.currentText().split(" - ")[0]  # Si la opción es "MAT101 - Matemáticas"

        if self.__primero.isChecked():
            grado=1
        elif self.__segundo.isChecked():
            grado=2
        elif self.__tercero.isChecked():
            grado=3

        if self.__grupoA.isChecked():
            grupo='A'
        elif self.__grupoB.isChecked():
            grupo='B'
        elif self.__grupoC.isChecked():
            grupo='C'

        self.cargar_materias(clave_profesor, grupo, grado)   

        try:
            conexion = crear_conexion()
            cursor = conexion.cursor(dictionary=True) 

            consulta = """
                SELECT u.clave, u.nombre, u.apellidoP, u.apellidoM
                FROM grupo_alumno as g
                JOIN usuario as u ON g.clave_alumno = u.clave
                JOIN profesor_materia_grupo as pmg ON g.grupo = pmg.grupo
                JOIN materia as m ON m.clave=pmg.clave_materia
                WHERE pmg.clave_profesor = %s AND pmg.grupo=%s AND m.grado=%s;
            """
            cursor.execute(consulta, (clave_profesor, grupo,grado))
            resultados = cursor.fetchall()

            self.tabla.setRowCount(0)  # Limpia la tabla
            for fila_num, fila_datos in enumerate(resultados):
                valores = [fila_datos["clave"], fila_datos["nombre"], fila_datos["apellidoP"], fila_datos["apellidoM"]]
                self.tabla.insertRow(fila_num)
                for col_num, valor in enumerate(valores):
                    self.tabla.setItem(fila_num, col_num, QTableWidgetItem(str(valor)))

            self.tabla.show()
            self.__bBuscarG.hide()
            self.__bCancelar1.hide()
            self.__bSalir.show()
            cursor.close()
            conexion.close()

        except mysql.connector.Error as err:
            QMessageBox.critical(self, "Error al listar", f"Ocurrió un error: {err}")

    @Slot()
    def cancelar(self):
        resp=QMessageBox.question(
            self,
            'Comfirmar',
            "¿Deseas cancelar la operación? ",
            QMessageBox.Yes|QMessageBox.No,
            QMessageBox.No 
        )

        if resp==QMessageBox.Yes:
            self.cancelarSignal.emit()

    @Slot()
    def salir(self):
        self.salirSignal.emit()

class GenerarActa(QMainWindow):
    generarSignal = Signal()
    salirSignal = Signal()
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Consultar Grupo")

        self.__consular = QLabel('CONSULTAR GRUPO')
        self.__consular.setAlignment(Qt.AlignCenter)
        self.__grado = QLabel('Grado:')
        self.__primero = QRadioButton('1°')
        self.__segundo = QRadioButton('2°')
        self.__tercero = QRadioButton('3°')

        self.__grupo = QLabel('Grupo:')
        self.__grupoA = QRadioButton('A')
        self.__grupoB = QRadioButton('B')
        self.__grupoC = QRadioButton('C')

        self.__grupo_grado = QButtonGroup(self)
        self.__grupo_grado.addButton(self.__primero)
        self.__grupo_grado.addButton(self.__segundo)
        self.__grupo_grado.addButton(self.__tercero)

        self.__grupo_grupo = QButtonGroup(self)
        self.__grupo_grupo.addButton(self.__grupoA)
        self.__grupo_grupo.addButton(self.__grupoB)
        self.__grupo_grupo.addButton(self.__grupoC)

        self.__bGuardar = QPushButton('Guardar')

        self.tabla = QTableWidget(3, 4)
        self.tabla.setHorizontalHeaderLabels(['NOMBRE', 'APELLIDO PATERNO', 'APELLIDO MATERNO', 'CALIFICACIÓN'])
        self.tabla.setColumnWidth(3, 200)
        self.tabla.hide()
        self.__calGrupos = []

        self.__bBuscar = QPushButton('Buscar grupo')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bSalir = QPushButton('Salir')
        self.__bSalir.hide()
        self.__bGuardar.hide()

        layoutQV1 = QVBoxLayout()
        layoutQV1.addWidget(self.__grado)
        layoutQV1.addWidget(self.__primero)
        layoutQV1.addWidget(self.__segundo)
        layoutQV1.addWidget(self.__tercero)

        layoutQV2 = QVBoxLayout()
        layoutQV2.addWidget(self.__grupo)
        layoutQV2.addWidget(self.__grupoA)
        layoutQV2.addWidget(self.__grupoB)
        layoutQV2.addWidget(self.__grupoC)

        layoutQH3 = QHBoxLayout()
        layoutQH3.addLayout(layoutQV1)
        layoutQH3.addLayout(layoutQV2)

        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bGuardar)
        layoutQH2.addWidget(self.__bSalir)

        layoutQV = QVBoxLayout()
        layoutQV.addWidget(self.__consular)
        layoutQV.addWidget(self.tabla)
        layoutQV.addLayout(layoutQH3)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addLayout(layoutQH2)

        self.__bBuscar.clicked.connect(self.buscar)
        self.__bGuardar.clicked.connect(self.guardar)

        widgetPrincipal = QWidget()
        widgetPrincipal.setLayout(layoutQV)
        self.setCentralWidget(widgetPrincipal)

    @Slot()
    def buscar(self):
        from Conexion import crear_conexion

        if self.__primero.isChecked():
            grado = 1
        elif self.__segundo.isChecked():
            grado = 2
        elif self.__tercero.isChecked():
            grado = 3
        else:
            QMessageBox.warning(self, "Grado", "Debes seleccionar un grado.")
            return

        if self.__grupoA.isChecked():
            grupo = 'A'
        elif self.__grupoB.isChecked():
            grupo = 'B'
        elif self.__grupoC.isChecked():
            grupo = 'C'
        else:
            QMessageBox.warning(self, "Grupo", "Debes seleccionar un grupo.")
            return

        try:
            conexion = crear_conexion()
            cursor = conexion.cursor(dictionary=True)

            query = """
                SELECT u.nombre, u.apellidoP, u.apellidoM
                FROM grupo_alumno AS g
                JOIN usuario AS u ON g.clave_alumno = u.clave
                WHERE g.grado = %s AND g.grupo = %s
            """
            cursor.execute(query, (grado, grupo))
            alumnos = cursor.fetchall()

            self.tabla.setRowCount(len(alumnos))
            self.__calGrupos.clear()

            for fila, alumno in enumerate(alumnos):
                self.tabla.setItem(fila, 0, QTableWidgetItem(alumno['nombre']))
                self.tabla.setItem(fila, 1, QTableWidgetItem(alumno['apellidoP']))
                self.tabla.setItem(fila, 2, QTableWidgetItem(alumno['apellidoM']))

                # Calificación
                calificacion = QWidget()
                layoutRadio = QHBoxLayout()
                layoutRadio.setContentsMargins(0, 0, 0, 0)

                rbNa = QRadioButton("NA")
                rbS = QRadioButton("S")
                rbB = QRadioButton("B")
                rbMB = QRadioButton("MB")

                grupo_rb = QButtonGroup(calificacion)
                for rb in [rbNa, rbS, rbB, rbMB]:
                    layoutRadio.addWidget(rb)
                    grupo_rb.addButton(rb)

                calificacion.setLayout(layoutRadio)
                self.tabla.setCellWidget(fila, 3, calificacion)
                self.__calGrupos.append(grupo_rb)

            cursor.close()
            conexion.close()

            self.__bBuscar.hide()
            self.__bCancelar1.hide()
            self.__grado.hide()
            self.__grupo.hide()
            self.__primero.hide()
            self.__segundo.hide()
            self.__tercero.hide()
            self.__grupoA.hide()
            self.__grupoB.hide()
            self.__grupoC.hide()
            self.__bGuardar.show()
            self.__bSalir.show()
            self.tabla.show()

        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo consultar a los alumnos: {e}")


    @Slot()
    def guardar(self):
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from PySide6.QtWidgets import QFileDialog

        # Confirmación
        if QMessageBox.information(
            self, 'Confirmar', '¿Deseas guardar el acta como PDF?',
            QMessageBox.Ok | QMessageBox.Cancel, QMessageBox.Ok
        ) != QMessageBox.Ok:
            return

        # Selección de ubicación de guardado
        ruta_pdf, _ = QFileDialog.getSaveFileName(
            self, "Guardar Acta como PDF", "acta.pdf", "Archivos PDF (*.pdf)"
        )
        if not ruta_pdf:
            return

        # Crear el canvas del PDF
        c = canvas.Canvas(ruta_pdf, pagesize=A4)
        width, height = A4
        y = height - 50  # Margen superior

        c.setFont("Helvetica-Bold", 14)
        c.drawCentredString(width / 2, y, "ACTA DE CALIFICACIONES")
        y -= 40

        c.setFont("Helvetica", 11)
        c.drawString(50, y, f"Fecha: {datetime.now().strftime('%d/%m/%Y')}")
        y -= 30

        # Encabezados de tabla
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y, "Nombre")
        c.drawString(200, y, "Apellido P.")
        c.drawString(350, y, "Apellido M.")
        c.drawString(500, y, "Calificación")
        y -= 20
        c.setFont("Helvetica", 11)

        # Agregar alumnos
        for fila in range(self.tabla.rowCount()):
            nombre = self.tabla.item(fila, 0).text()
            ape_p = self.tabla.item(fila, 1).text()
            ape_m = self.tabla.item(fila, 2).text()

            grupo_rb = self.__calGrupos[fila]
            calificacion = next(
                (rb.text() for rb in grupo_rb.buttons() if rb.isChecked()), "Sin calificar"
            )

            if y < 50:  # Nueva página si no hay espacio
                c.showPage()
                y = height - 50

            c.drawString(50, y, nombre)
            c.drawString(200, y, ape_p)
            c.drawString(350, y, ape_m)
            c.drawString(500, y, calificacion)
            y -= 20

        c.save()
        QMessageBox.information(self, "Éxito", "El acta se ha guardado correctamente en PDF.")

    @Slot()
    def salir(self):
        self.salirSignal.emit()

class ReporteAgregar(QWidget):
    subirSignal = Signal()
    cancelarSignal = Signal()

    def __init__(self):
        super().__init__()

        #Widgets
        self.__titulo = QLabel('Ingrese el asunto: ')
        self.__tituloT=QLineEdit()
        self.__descripcion = QLabel('Descripción: ')
        self.__descripcionT=QTextEdit()
        self.__claveMateria=QLabel("Clave de la materia:")
        self.__claveMateriaT=QLineEdit()
        self.__claveAlumno=QLabel("Clave alumno:")
        self.__claveAlumnoT=QLineEdit()
        self.__bSubir = QPushButton('Enviar reporte')
        self.__bCancelar = QPushButton('Cancelar')

        # Layout Formulario
        layoutForm = QFormLayout()
        layoutForm.addRow(self.__claveAlumno,self.__claveAlumnoT)
        layoutForm.addRow(self.__claveMateria,self.__claveMateriaT)
        layoutForm.addRow(self.__titulo,self.__tituloT)
        layoutForm.addRow(self.__descripcion)
        layoutForm.addRow(self.__descripcionT)

        # Layout Botones
        layoutQH = QHBoxLayout()
        layoutQH.addWidget(self.__bSubir)
        layoutQH.addWidget(self.__bCancelar)

        #Layout Principal
        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH)
        self.setLayout(layoutQV)

        #Conexiones 
        self.__bSubir.clicked.connect(self.subir)
        self.__bCancelar.clicked.connect(self.cancelar)
    
    @Slot()
    def subir(self):
        if QMessageBox.information(
            self,
            '',
            'Verifica que los datos sean correctos',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Ok
        ) == QMessageBox.Ok:
            self.subirSignal.emit()

        alumno=self.__claveAlumnoT.text()
        materia=self.__claveMateriaT.text()
        asunto=self.__tituloT.text()
        descripcion=self.__descripcionT.toPlainText()
        fecha=datetime.now() 
      
        reporte= Reporte(fecha, asunto, descripcion,alumno,materia)
        exito= insertar_reporte(
            reporte.fecha,
            reporte.asunto,
            reporte.descripcion,
            reporte.clave_alumno,
            reporte.clave_materia)

        if exito:
            QMessageBox.information(self, 'Éxito', 'Reporte fue registrado correctamente.')
            self.subirSignal.emit()
        else:
            QMessageBox.critical(self, 'Error', 'No se pudo registrar el reporte.')


    @Slot()
    def cancelar(self):
        if QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que quieres cancelar?\nLos cambios no se guardarán',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Cancel
        ) == QMessageBox.Ok:
            self.cancelarSignal.emit()
    
class ReporteBorrar(QWidget):
    borrarSignal = Signal()
    cancelarSignal = Signal()
    
    def __init__(self):
        super().__init__()
        
        # Widgets
        self.__clave = QLabel('Inserte el numero de reporte:')
        self.__lClave = QLineEdit()
        self.__bBuscar = QPushButton('Buscar reporte')
        self.__bCancelar1 = QPushButton('Cancelar')
        self.__bCancelar2 = QPushButton('Cancelar')
        self.__bBorrar = QPushButton('Eliminar')
        self.__infoReporte = QLabel('Reporte')
        self.__infoReporte.hide()
        self.__bBorrar.hide()
        self.__bCancelar2.hide()
        
        # Layout formulario
        layoutForm = QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lClave)

        # Layout botones buscar
        layoutQH1 = QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addWidget(self.__bCancelar1)

        # Layout botones mostrar
        layoutQH2 = QHBoxLayout()
        layoutQH2.addWidget(self.__bBorrar)
        layoutQH2.addWidget(self.__bCancelar2)

        # Layout principal
        layoutQV = QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addWidget(self.__infoReporte)
        layoutQV.addLayout(layoutQH2)
        self.setLayout(layoutQV)

        # Conexiones
        
        self.__bBuscar.clicked.connect(self.buscar)
        self.__bBorrar.clicked.connect(self.borrar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bCancelar2.clicked.connect(self.cancelar)

    @Slot()
    def buscar(self):
        clave = self.__lClave.text().strip()
        
        if not clave:
            QMessageBox.warning(self, "Advertencia", "Por favor ingresa un número de reporte.")
            return

        reporte = buscar_reporte(clave)
        if reporte:
            texto = f"""
                ID: {reporte["id"]}
                Fecha: {reporte["fecha"]}
                Asunto: {reporte["asunto"]}
                Clave alumno: {reporte["claveAlumno"]}
                Clave materia: {reporte["claveMateria"]}
                Descripción: {reporte["descripcion"]}
                """
            self.__infoReporte.setText(texto.strip())
            

        self.__clave.hide()
        self.__lClave.hide()
        self.__bBuscar.hide()
        self.__bCancelar1.hide()
        self.__infoReporte.show()
        self.__bBorrar.show()
        self.__bCancelar2.show()
    
    @Slot()
    def borrar(self):
        resp=QMessageBox.information(
            
            self,
            '',
            'Seguro que deseas borrar el reporte',
            QMessageBox.Ok | QMessageBox.Cancel,
            QMessageBox.Ok)
        
        clave=self.__lClave.text()
      
        if QMessageBox.Ok==resp:
            clave = self.__lClave.text().strip()
            if borrar_reporte(clave):
                QMessageBox.information(self, 'Eliminado', 'El reporte ha sido eliminado correctamente.')
                self.borrarSignal.emit()
            else:
                QMessageBox.critical(self, 'Error', 'No se pudo eliminar el reporte.')

    
    @Slot()
    def cancelar(self):
        resp = QMessageBox.question(
            self,
            'Cancelar',
            '¿Seguro que deseas cancelar la operación?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self.cancelarSignal.emit()