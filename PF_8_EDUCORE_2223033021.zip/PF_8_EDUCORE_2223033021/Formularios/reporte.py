import sys

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

class ReporteMostra(QMainWindow):
    cancelarSignal=Signal()
    salirSignal=Signal()

    def __init__(self):
        super().__init__()

        #Widgets 
        self.__clave =QLabel('Inserte el numero del reporte:')
        self.__lclave=QLineEdit()
        self.__bBuscar=QPushButton('Mostrar reporte')
        self.__bCancelar1=QPushButton('Cancelar')
        self.__bCancelar2=QPushButton('Salir')
        self.__infoReporte=QLabel('Descripcion')
        self.__infoReporte.hide()
        self.__bCancelar2.hide()
        #Layout formulario 
        layoutForm=QFormLayout()
        layoutForm.addRow(self.__clave)
        layoutForm.addRow(self.__lclave)

        #Layout botones buscar y cancelar 
        layoutQH1=QHBoxLayout()
        layoutQH1.addWidget(self.__bBuscar)
        layoutQH1.addChildWidget(self.__bCancelar1)

        #Layout botón salir 
        layoutQH2=QHBoxLayout()
        layoutQH2.addWidget(self.__bCancelar2)

        #Layout principal 
        layoutQV=QVBoxLayout()
        layoutQV.addLayout(layoutForm)
        layoutQV.addLayout(layoutQH1)
        layoutQV.addWidget(self.__infoReporte)
        layoutQV.addLayout(layoutQH2)
        self.setLayout
        
        #Conexiones
        self.__bBuscar.clicked.connect(self.buscar)
        self.__bCancelar1.clicked.connect(self.cancelar)
        self.__bCancelar2.clicked.connect(self.salir)

    @Slot()
    def buscar(self):
        clave_report=self.__lclave.text().strip()
        if not clave_report:
            QMessageBox(
                self,"Advertencia",
                "Verifique la clave del reporte."
            )
        self.__clave.hide()
        self.__lclave.hide()
        self.__bBuscar.hide()
        self.__bCancelar1.hide()
        self.__infoReporte.show()
        self.__bCancelar2.show()


    @Slot()
    def cancelar(self):
        resp=QMessageBox.question(
            self,
            'Comfirmar',
            "¿Deseas cancelar la operación? ",
            QMessageBox.Yes|QMessageBox.No,
            QMessageBox.No 
        )

        if resp==QMessageBox.Yes:
            self.cancelarSignal.emit()


    @Slot()
    def salir(self):
        self.salirSignal.emit()
        
if __name__ == '__main__':
    app = QApplication()
    ventana = ReporteMostra()
    ventana.show()
    app.exec()