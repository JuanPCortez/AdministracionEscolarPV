from Conexion import *

class Materia():
    
    def __init__(self,clave,nombre,grado,grupo,clave_profesor):
        self.__clave = clave
        self.__nombre = nombre
        self.__grado = grado
        self.__grupo = grupo
        self.__clave_profesor = clave_profesor
    
    @property
    def clave(self):
        return self.__clave
    
    @property
    def nombre(self):
        return self.__nombre
    
    @property
    def grado(self):
        return self.__grado
    
    @property
    def grupo(self):
        return self.__grupo
    
    @property
    def clave_profesor(self):
        return self.__clave_profesor
    
    @clave.setter
    def clave(self,clave):
        self.__clave = clave
    
    @nombre.setter
    def nombre(self,nombre):
        self.__nombre = nombre
    
    @grado.setter
    def grado(self,grado):
        self.__grado = grado

    @grupo.setter
    def grupo(self,grupo):
        self.__grupo = grupo
    
    @clave_profesor.setter
    def clave_profesor(self,clave_profesor):
        self.__clave_profesor = clave_profesor
    
    __contador = obtener_ultimo_id_materia() + 1
    @classmethod
    def generar_clave(cls):
        clave = f"MAT{cls.__contador:03}"
        cls.__contador += 1
        return clave
    
    def __str__(self):
        return f'Clave:{self.__clave}\nNombre: {self.__nombre}\
            \nGrado: {self.__grado}\nGrupo: {self.__grupo}\n\
            Profesor: {self.__clave_profesor}'