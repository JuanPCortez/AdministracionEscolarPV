from Usuarios.Persona import Persona

class Administrador(Persona):

    def __init__(self,nombre,apellidoP,apellidoM,edad,curp,correo,contrasena=None,clave=None):
        super().__init__(nombre,apellidoP,apellidoM,edad,curp,correo)
        self.__clave = clave if clave else self.generarClave()
        self.__contrasena = contrasena if contrasena else self.generarContrasena()
    
    @property
    def clave(self):
        return self.__clave
    
    @property
    def contrasena(self):
        return self.__contrasena
    
    @clave.setter
    def clave(self,clave):
        self.__clave = clave
    
    @contrasena.setter
    def contrasena(self,contrasena):
        self.__contrasena = contrasena

    def obtenerRol(self):
        return 'Administrador'
    
    def generarClave(self):
        self.__clave = self.generarClavePrefijo('A')
        return self.__clave
    
    def __str__(self):
        return f'Clave: {self.__clave}\n' + super().__str__() + f'Rol: {self.obtenerRol()}\n'

