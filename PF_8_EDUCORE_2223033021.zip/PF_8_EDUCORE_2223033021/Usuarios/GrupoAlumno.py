from Conexion import *

class GrupoAlumno():
    
    def __init__(self,clave_alumno,grado,grupo):
        self.__clave_alumno = clave_alumno
        self.__grado = grado
        self.__grupo = grupo
    
    @property
    def clave_alumno(self):
        return self.__clave_alumno
    
    @property
    def grado(self):
        return self.__grado
    
    @property
    def grupo(self):
        return self.__grupo
    
    
    @clave_alumno.setter
    def clave_alumno(self,clave_alumno):
        self.__clave_alumno = clave_alumno
    
    @grado.setter
    def grado(self,grado):
        self.__grado = grado

    @grupo.setter
    def grupo(self,grupo):
        self.__grupo = grupo
    