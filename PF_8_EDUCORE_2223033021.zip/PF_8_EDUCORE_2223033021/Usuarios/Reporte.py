class Reporte():
    
    def __init__(self,fecha,asunto,descripcion,clave_alumno,clave_materia,id=None):
        self.__id = id
        self.__fecha = fecha
        self.__asunto = asunto
        self.__descripcion = descripcion
        self.__clave_alumno = clave_alumno
        self.__clave_materia = clave_materia
    
    @property
    def id(self):
        return self.__id
    
    @property
    def fecha(self):
        return self.__fecha
    
    @property
    def asunto(self):
        return self.__asunto
    
    @property
    def descripcion(self):
        return self.__descripcion
    
    @property
    def clave_alumno(self):
        return self.__clave_alumno
    
    @property
    def clave_materia(self):
        return self.__clave_materia
    
    @id.setter
    def id(self,id):
        self.__id = id

    @fecha.setter
    def fecha(self,fecha):
        self.__fecha = fecha
    
    @asunto.setter
    def asunto(self,asunto):
        self.__asunto = asunto

    @descripcion.setter
    def descripcion(self,descripcion):
        self.__descripcion = descripcion
    
    @clave_alumno.setter
    def clave_alumno(self,clave_alumno):
        self.__clave_alumno = clave_alumno
    
    @clave_materia.setter
    def clave_materia(self,clave_materia):
        self.__clave_materia = clave_materia
    
    def __str__(self):
        return f'Reporte: {self.__id}\n\
            Fecha: {self.__fecha}\n\
            Asunto: {self.__asunto}\n\
            Descripción: {self.__descripcion}\n\
            Alumno: {self.__clave_alumno}\n\
            Materia: {self.__clave_materia}'