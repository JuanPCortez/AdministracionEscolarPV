class Anuncio():

    def __init__(self,id,titulo,descripcion,fecha_publicacion):
        self.__id = id
        self.__titulo = titulo
        self.__descripcion = descripcion
        self.__fecha_publicacion = fecha_publicacion
    
    @property
    def id(self):
        return self.__id
    
    @property
    def titulo(self):
        return self.__titulo
    
    @property
    def descripcion(self):
        return self.__descripcion
    
    @property
    def fecha_publicacion(self):
        return self.__fecha_publicacion
    
    @id.setter
    def id_anuncio(self,id):
        self.__id = id
    
    @titulo.setter
    def titulo(self,titulo):
        self.__titulo = titulo
    
    @descripcion.setter
    def descripcion(self,descripcion):
        self.__descripcion = descripcion
    
    @fecha_publicacion.setter
    def fecha_publicacion(self,fecha_publicacion):
        self.__fecha_publicacion = fecha_publicacion
    
    def __str__(self):
        return f'Anuncio: {self.__id}\n\
            Titulo: {self.__titulo}\n\
            Descripción: {self.__descripcion}\n\
            Fecha: {self.__fecha_publicacion}'