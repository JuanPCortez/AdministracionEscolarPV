import random

from abc import ABC,abstractmethod

class Persona(ABC):

    def __init__(self, nombre, apellidoP, apellidoM, edad, curp, correo):
        self.__nombre = nombre
        self.__apellidoP = apellidoP
        self.__apellidoM = apellidoM
        self.__edad = edad
        self.__curp = curp
        self.__correo = correo
    
    @property
    def nombre(self):
        return self.__nombre
    
    @property
    def apellidoP(self):
        return self.__apellidoP
    
    @property
    def apellidoM(self):
        return self.__apellidoM
    
    @property 
    def edad(self):
        return self.__edad
    
    @property
    def curp(self):
        return self.__curp
    
    @property
    def correo(self):
        return self.__correo
    
    @nombre.setter
    def nombre(self,nombre):
        self.__nombre = nombre
    
    @apellidoP.setter
    def apellidoP(self,apellidoP):
        self.__apellidoP = apellidoP
    
    @apellidoM.setter
    def apellidoM(self,apellidoM):
        self.__apellidoM = apellidoM

    @edad.setter
    def edad(self,edad):
        self.__edad = edad
    
    @curp.setter
    def curp(self,curp):
        self.__curp = curp
    
    @correo.setter
    def correo(self,correo):
        self.__correo = correo
    
    @abstractmethod
    def obtenerRol(self):
        pass

    def generarClavePrefijo(self,prefijo):
        numeros = ''.join([str(random.randint(0,9)) for _ in range(5)])
        return prefijo + numeros
    
    @staticmethod
    def generarContrasena():
        return ''.join([str(random.randint(0, 9)) for _ in range(5)])
    
    def __str__(self):
        return f'Nombre: {self.__nombre}\nApellido Paterno: {self.__apellidoP}\
            \nApellido Materno: {self.__apellidoM}\nEdad: {self.__edad}\n\
            Curp: {self.__curp}\nCorreo: {self.__correo}\n'