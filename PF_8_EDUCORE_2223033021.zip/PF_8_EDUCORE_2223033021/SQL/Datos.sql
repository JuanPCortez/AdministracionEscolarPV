USE uamitos;

INSERT INTO usuario VALUES 
('M00000', 'USUARIO',     'MAESTRO',     '1',    45, 'LOSM450101HDFRNS01', 'maria.lopez@sec.com', 'root', 'Maestro'),
('M00001', 'María',     'López',     'Sánchez',    45, 'LOSM450101HDFRNS01', 'maria.lopez@sec.com', 'm1234', 'Maestro'),
('M00002', 'Carlos',    'Ramírez',   'Díaz',       50, 'RADC500223HGTLMR02', 'carlos.ram@sec.com',   'm2345', 'Maestro'),
('M00003', 'Gloria',    'Hernández', 'Vega',       48, 'HEVG480615MGTZLR03', 'gloria.hern@sec.com',  'm3456', 'Maestro'),
('M00004', 'Javier',    'Cruz',      'Ortiz',      42, 'CUOJ420912HGRRTV04', 'javier.cruz@sec.com',  'm4567', 'Maestro'),
('M00005', 'Rosa',      'Martínez',  'Paredes',    47, 'MAPR470203MDFTRR05', 'rosa.mart@sec.com',    'm5678', 'Maestro');

INSERT INTO usuario VALUES 
('A00001', 'Sofía',     'Torres',    'Mendoza',    38, 'TOMS380114MPLNDL06', 'sofia.tor@sec.com',    'a1111', 'Administrador'),
('A00002', 'Luis',      'Navarro',   'Zamora',     40, 'NAZL400408HGTPLS07', 'luis.nav@sec.com',     'a2222', 'Administrador'),
('A00003', 'Elena',     'Domínguez', 'Silva',      35, 'DOSL350709MTRVRS08', 'elena.dom@sec.com',    'a3333', 'Administrador'),
('A00004', 'Pedro',     'Salinas',   'Cano',       39, 'SACP390201HNLCTD09', 'pedro.sal@sec.com',    'a4444', 'Administrador'),
('A00005', 'Valeria',   'Gómez',     'Ibarra',     36, 'GOIV360725MCHLBR10', 'valeria.gom@sec.com',  'a5555', 'Administrador');

INSERT INTO usuario VALUES 
('P00001', 'Antonio',   'Morales',   'Luna',       33, 'MOLU330101HDFNRA11', 'antonio.mor@sec.com',  'p1111', 'Profesor'),
('P00002', 'Isabel',    'Fernández', 'Ruiz',       31, 'FERR310318MGRNBL12', 'isabel.fer@sec.com',   'p2222', 'Profesor'),
('P00003', 'Miguel',    'Castro',    'Pérez',      34, 'CAMP340507HDFNZN13', 'miguel.cas@sec.com',   'p3333', 'Profesor'),
('P00004', 'Verónica',  'Cabrera',   'Soto',       32, 'CASV320824MJNSRR14', 'vero.cab@sec.com',     'p4444', 'Profesor'),
('P00005', 'Raúl',      'Aguilar',   'Reyes',      35, 'AGRR350219HMNLLL15', 'raul.agu@sec.com',     'p5555', 'Profesor');

INSERT INTO usuario VALUES 
('E00001', 'Diego',     'Flores',    'Martínez',   14, 'FOMD110201HMNCTR16', 'diego.flo@sec.com',    'e1111', 'Alumno'),
('E00002', 'Camila',    'Herrera',   'Cruz',       13, 'HECC110719MJNRRS17', 'camila.her@sec.com',   'e2222', 'Alumno'),
('E00003', 'Alan',      'Jiménez',   'Ortiz',      15, 'JIOA110407HSLMNT18', 'alan.jim@sec.com',     'e3333', 'Alumno'),
('E00004', 'Fernanda',  'Santos',    'Moreno',     13, 'SAMF110328MGNTRS19', 'fer.sant@sec.com',     'e4444', 'Alumno'),
('E00005', 'Bruno',     'Nieto',     'Vargas',     14, 'NIVB110613HDFNRR20', 'bruno.nie@sec.com',    'e5555', 'Alumno');

SELECT * FROM usuario;

INSERT INTO materia VALUES
('MAT0101', 'Matemáticas I',           1),
('MAT0102', 'Español I',               1),
('MAT0103', 'Ciencias I (Biología)',   1),
('MAT0104', 'Geografía de México',     1),
('MAT0105', 'Educación Física I',      1),
('MAT0106', 'Formación Cívica I',      1),
('MAT0107', 'Educación Artística I',   1),
('MAT0108', 'Tecnología I',            1),
('MAT0109', 'Inglés I',                1),

('MAT0201', 'Matemáticas II',          2),
('MAT0202', 'Español II',              2),
('MAT0203', 'Ciencias II (Física)',    2),
('MAT0204', 'Historia I',              2),
('MAT0205', 'Educación Física II',     2),
('MAT0206', 'Formación Cívica II',     2),
('MAT0207', 'Educación Artística II',  2),
('MAT0208', 'Tecnología II',           2),
('MAT0209', 'Inglés II',               2),

('MAT0301', 'Matemáticas III',         3),
('MAT0302', 'Español III',             3),
('MAT0303', 'Ciencias III (Química)',  3),
('MAT0304', 'Historia II',             3),
('MAT0305', 'Educación Física III',    3),
('MAT0306', 'Formación Cívica III',    3),
('MAT0307', 'Educación Artística III', 3),
('MAT0308', 'Tecnología III',          3),
('MAT0309', 'Inglés III',              3);


INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Falta de materiales', 'Observación relacionada con el alumno E00001 en la materia MAT0101.', 'E00001', 'MAT0101');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Conducta', 'Observación relacionada con el alumno E00002 en la materia MAT0102.', 'E00002', 'MAT0102');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Tarea no entregada', 'Observación relacionada con el alumno E00003 en la materia MAT0103.', 'E00003', 'MAT0103');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Participación', 'Observación relacionada con el alumno E00004 en la materia MAT0104.', 'E00004', 'MAT0104');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Reconocimiento', 'Observación relacionada con el alumno E00005 en la materia MAT0105.', 'E00005', 'MAT0105');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Falta de materiales', 'Observación relacionada con el alumno E00001 en la materia MAT0106.', 'E00001', 'MAT0106');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Conducta', 'Observación relacionada con el alumno E00002 en la materia MAT0107.', 'E00002', 'MAT0107');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Tarea no entregada', 'Observación relacionada con el alumno E00003 en la materia MAT0108.', 'E00003', 'MAT0108');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Participación', 'Observación relacionada con el alumno E00004 en la materia MAT0109.', 'E00004', 'MAT0109');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Reconocimiento', 'Observación relacionada con el alumno E00005 en la materia MAT0201.', 'E00005', 'MAT0201');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Falta de materiales', 'Observación relacionada con el alumno E00001 en la materia MAT0202.', 'E00001', 'MAT0202');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Conducta', 'Observación relacionada con el alumno E00002 en la materia MAT0203.', 'E00002', 'MAT0203');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Tarea no entregada', 'Observación relacionada con el alumno E00003 en la materia MAT0204.', 'E00003', 'MAT0204');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Participación', 'Observación relacionada con el alumno E00004 en la materia MAT0205.', 'E00004', 'MAT0205');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Reconocimiento', 'Observación relacionada con el alumno E00005 en la materia MAT0206.', 'E00005', 'MAT0206');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Falta de materiales', 'Observación relacionada con el alumno E00001 en la materia MAT0207.', 'E00001', 'MAT0207');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Conducta', 'Observación relacionada con el alumno E00002 en la materia MAT0208.', 'E00002', 'MAT0208');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Tarea no entregada', 'Observación relacionada con el alumno E00003 en la materia MAT0209.', 'E00003', 'MAT0209');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Participación', 'Observación relacionada con el alumno E00004 en la materia MAT0301.', 'E00004', 'MAT0301');
INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES ('2025-08-03', 'Reconocimiento', 'Observación relacionada con el alumno E00005 en la materia MAT0302.', 'E00005', 'MAT0302');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0101', 'P00001', 'A');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0102', 'P00002', 'B');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0103', 'P00003', 'C');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0104', 'P00004', 'A');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0105', 'P00005', 'B');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0106', 'P00001', 'C');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0107', 'P00002', 'A');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0108', 'P00003', 'B');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0109', 'P00004', 'C');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0201', 'P00005', 'A');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0202', 'P00001', 'B');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0203', 'P00002', 'C');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0204', 'P00003', 'A');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0205', 'P00004', 'B');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0206', 'P00005', 'C');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0207', 'P00001', 'A');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0208', 'P00002', 'B');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0209', 'P00003', 'C');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0301', 'P00004', 'A');
INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES ('MAT0302', 'P00005', 'B');
INSERT INTO grupo_alumno (clave_alumno, grado, grupo) VALUES ('E00001', 2, 'A');
INSERT INTO grupo_alumno (clave_alumno, grado, grupo) VALUES ('E00002', 2, 'A');
INSERT INTO grupo_alumno (clave_alumno, grado, grupo) VALUES ('E00003', 2, 'B');
INSERT INTO grupo_alumno (clave_alumno, grado, grupo) VALUES ('E00004', 1, 'B');
INSERT INTO grupo_alumno (clave_alumno, grado, grupo) VALUES ('E00005', 3, 'A');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0101', 'P00001', 'Lunes', '08:00:00', '08:50:00', 'A');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0102', 'P00002', 'Martes', '08:50:00', '09:40:00', 'B');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0103', 'P00003', 'Miércoles', '09:40:00', '10:30:00', 'C');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0104', 'P00004', 'Jueves', '10:30:00', '11:20:00', 'A');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0105', 'P00005', 'Viernes', '11:20:00', '12:10:00', 'B');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0106', 'P00001', 'Lunes', '12:10:00', '13:00:00', 'C');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0107', 'P00002', 'Martes', '13:00:00', '13:50:00', 'A');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0108', 'P00003', 'Miércoles', '13:50:00', '14:40:00', 'B');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0109', 'P00004', 'Jueves', '14:40:00', '15:30:00', 'C');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0201', 'P00005', 'Viernes', '15:30:00', '16:20:00', 'A');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0202', 'P00001', 'Lunes', '16:20:00', '17:10:00', 'B');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0203', 'P00002', 'Martes', '17:10:00', '18:00:00', 'C');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0204', 'P00003', 'Miércoles', '18:00:00', '18:50:00', 'A');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0205', 'P00004', 'Jueves', '18:50:00', '19:40:00', 'B');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0206', 'P00005', 'Viernes', '19:40:00', '20:30:00', 'C');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0207', 'P00001', 'Lunes', '20:30:00', '21:20:00', 'A');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0208', 'P00002', 'Martes', '21:20:00', '22:10:00', 'B');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0209', 'P00003', 'Miércoles', '22:10:00', '23:00:00', 'C');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0301', 'P00004', 'Jueves', '23:00:00', '23:50:00', 'A');
INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES ('MAT0302', 'P00005', 'Viernes', '23:50:00', '00:40:00', 'B');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Bienvenida al ciclo escolar', 'Bienvenida al ciclo escolar se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Simulacro de evacuación', 'Simulacro de evacuación se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Entrega de boletas', 'Entrega de boletas se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Taller de ciencias', 'Taller de ciencias se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Concurso de ortografía', 'Concurso de ortografía se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Campaña de reciclaje', 'Campaña de reciclaje se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Semana de la salud', 'Semana de la salud se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Reunión de padres', 'Reunión de padres se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Evaluación diagnóstica', 'Evaluación diagnóstica se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');
INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES ('Fiesta de clausura', 'Fiesta de clausura se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');

INSERT INTO reporte (fecha, asunto, descripcion, clave_alumno, clave_materia) VALUES 
('2025-08-03', 'Falta de materiales', 'El alumno no trajo su cuaderno.', 'E00003', 'MAT0209'),
('2025-08-03', 'Reconocimiento', 'Buen desempeño en clase.', 'E00005', 'MAT0208'),
('2025-08-03', 'Tarea no entregada', 'El alumno olvidó entregar la tarea semanal.', 'E00001', 'MAT0207'),
('2025-08-03', 'Conducta', 'Comportamiento disruptivo en clase.', 'E00004', 'MAT0206'),
('2025-08-03', 'Participación', 'Participó activamente en la actividad grupal.', 'E00003', 'MAT0205'),
('2025-08-03', 'Falta de materiales', 'No trajo libro de texto.', 'E00002', 'MAT0204'),
('2025-08-03', 'Reconocimiento', 'Excelente presentación de proyecto.', 'E00001', 'MAT0203'),
('2025-08-03', 'Tarea no entregada', 'Faltó a la entrega de la maqueta.', 'E00004', 'MAT0202'),
('2025-08-03', 'Conducta', 'Interrumpió en clase repetidamente.', 'E00005', 'MAT0201'),
('2025-08-03', 'Participación', 'Ayudó a sus compañeros.', 'E00003', 'MAT0109'),
('2025-08-03', 'Falta de materiales', 'No trajo material solicitado.', 'E00001', 'MAT0108'),
('2025-08-03', 'Reconocimiento', 'Actitud colaborativa.', 'E00004', 'MAT0107'),
('2025-08-03', 'Tarea no entregada', 'No entregó trabajo de investigación.', 'E00002', 'MAT0106'),
('2025-08-03', 'Conducta', 'Pelea verbal con compañero.', 'E00003', 'MAT0105'),
('2025-08-03', 'Participación', 'Participó en el debate.', 'E00001', 'MAT0104'),
('2025-08-03', 'Falta de materiales', 'Sin cuaderno.', 'E00002', 'MAT0103'),
('2025-08-03', 'Reconocimiento', 'Alumno destacado del mes.', 'E00005', 'MAT0102'),
('2025-08-03', 'Tarea no entregada', 'Faltó a clase y no presentó tarea.', 'E00004', 'MAT0101'),
('2025-08-03', 'Participación', 'Entusiasmo en actividades.', 'E00002', 'MAT0301'),
('2025-08-03', 'Conducta', 'Interrumpió la actividad.', 'E00005', 'MAT0302');

INSERT INTO grupo_alumno (clave_alumno, grado, grupo) VALUES 
('E00005', 2, 'A'),
('E00001', 1, 'C'),
('E00004', 2, 'B'),
('E00001', 1, 'A'),
('E00003', 2, 'C');

INSERT INTO profesor_materia_grupo (clave_materia, clave_profesor, grupo) VALUES 
('MAT0303', 'P00001', 'A'),
('MAT0304', 'P00002', 'B'),
('MAT0305', 'P00003', 'C'),
('MAT0306', 'P00004', 'A'),
('MAT0307', 'P00005', 'B'),
('MAT0308', 'P00001', 'C'),
('MAT0309', 'P00002', 'A'),
('MAT0102', 'P00003', 'C'),
('MAT0105', 'P00001', 'C'),
('MAT0106', 'P00005', 'B');

INSERT INTO horario (clave_materia, clave_profesor, dia, hora_inicio, hora_fin, grupo) VALUES 
('MAT0303', 'P00001', 'Lunes', '07:00:00', '07:50:00', 'A'),
('MAT0304', 'P00002', 'Martes', '07:00:00', '07:50:00', 'B'),
('MAT0305', 'P00003', 'Miércoles', '07:00:00', '07:50:00', 'C'),
('MAT0306', 'P00004', 'Jueves', '07:00:00', '07:50:00', 'A'),
('MAT0307', 'P00005', 'Viernes', '07:00:00', '07:50:00', 'B'),
('MAT0308', 'P00001', 'Lunes', '10:00:00', '10:50:00', 'C'),
('MAT0309', 'P00002', 'Martes', '10:00:00', '10:50:00', 'A'),
('MAT0102', 'P00003', 'Miércoles', '10:00:00', '10:50:00', 'B'),
('MAT0105', 'P00001', 'Jueves', '10:00:00', '10:50:00', 'C'),
('MAT0106', 'P00005', 'Viernes', '10:00:00', '10:50:00', 'B');

INSERT INTO anuncio (titulo, descripcion, fecha_publicacion) VALUES 
('Exposición de arte', 'Exposición de arte se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03'),
('Jornada deportiva', 'Jornada deportiva se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03'),
('Feria vocacional', 'Feria vocacional se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03'),
('Campamento escolar', 'Campamento escolar se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03'),
('Día de disfraces', 'Día de disfraces se llevará a cabo próximamente en Uamitos High School. ¡Participa!', '2025-08-03');

