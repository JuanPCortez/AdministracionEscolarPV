CREATE DATABASE IF NOT EXISTS uamitos CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE uamitos;

CREATE TABLE usuario(
	clave VARCHAR(10) PRIMARY KEY,
    nombre VARCHAR(20),
    apellidoP VARCHAR(20),
    apellidoM VARCHAR(20),
    edad INT,
    curp VARCHAR(18),
    correo VARCHAR(50),
    contrasena VARCHAR(20),
    rol VARCHAR(20)
)Engine = InnoDB;

CREATE TABLE materia(
	clave VARCHAR(10) PRIMARY KEY,
    nombre VARCHAR(50),
    grado INT
)Engine = InnoDB;

CREATE TABLE anuncio(
	id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(50),
    descripcion TEXT,
    fecha_publicacion DATE
)Engine = InnoDB;

CREATE TABLE reporte(
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    asunto VARCHAR(20),
    descripcion TEXT,
    clave_alumno VARCHAR(10),
    clave_materia VARCHAR(10),
    FOREIGN KEY (clave_alumno) REFERENCES usuario(clave) ON DELETE CASCADE,
    FOREIGN KEY (clave_materia) REFERENCES materia(clave) ON DELETE SET NULL
) Engine = InnoDB;

CREATE TABLE profesor_materia_grupo(
	id INT AUTO_INCREMENT PRIMARY KEY,
    clave_materia VARCHAR(10),
    clave_profesor VARCHAR(10),
    grupo VARCHAR(1),
    FOREIGN KEY (clave_profesor) REFERENCES usuario(clave) ON DELETE CASCADE,
    FOREIGN KEY (clave_materia) REFERENCES materia(clave) ON DELETE CASCADE
)Engine = InnoDB;

CREATE TABLE grupo_alumno(
	id INT AUTO_INCREMENT PRIMARY KEY,
    clave_alumno VARCHAR(10),
    grado INT,
    grupo VARCHAR(1),
    FOREIGN KEY (clave_alumno) REFERENCES usuario(clave) ON DELETE CASCADE
)Engine = InnoDB;

CREATE TABLE horario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    clave_materia VARCHAR(10) NOT NULL,
    clave_profesor VARCHAR(10) NOT NULL,
    dia ENUM('Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo') NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    grupo VARCHAR(10) NOT NULL,
    FOREIGN KEY (clave_materia) REFERENCES materia(clave) ON DELETE CASCADE,
    FOREIGN KEY (clave_profesor) REFERENCES usuario(clave) ON DELETE CASCADE
)Engine = InnoDB;


-- DROP DATABASE uamitos;




